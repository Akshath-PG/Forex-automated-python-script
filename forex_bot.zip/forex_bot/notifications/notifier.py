"""
=============================================================
  NOTIFICATIONS — TELEGRAM + WHATSAPP ALERT SYSTEM
  Sends trade alerts with full reasoning and waits for
  your confirmation before placing the order in MT5.

  Telegram: inline keyboard buttons (✅ BUY / ❌ SKIP)
  WhatsApp: text message (reply YES or NO)
=============================================================
"""

import logging
import asyncio
from datetime import datetime, timezone, timedelta
from typing import Optional, Callable
import os, sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.settings import *
from strategies.all_strategies import TradeSignal

logger = logging.getLogger(__name__)

# ── Telegram ──────────────────────────────────────────────

try:
    from telegram import Bot, InlineKeyboardButton, InlineKeyboardMarkup, Update
    from telegram.ext import Application, CallbackQueryHandler, MessageHandler, filters, ContextTypes
    TELEGRAM_AVAILABLE = True
except ImportError:
    TELEGRAM_AVAILABLE = False
    logger.warning("python-telegram-bot not installed.")

# ── WhatsApp ──────────────────────────────────────────────

try:
    from twilio.rest import Client as TwilioClient
    TWILIO_AVAILABLE = True
except ImportError:
    TWILIO_AVAILABLE = False
    logger.warning("twilio not installed.")


# ── Alert message formatter ───────────────────────────────

class AlertFormatter:
    """
    Formats a TradeSignal into a rich, readable alert message
    with full explanation of why the trade is being taken.
    """

    EMOJI_DIR = {"BUY": "🟢", "SELL": "🔴"}
    EMOJI_STRAT = {
        "Silver Bullet":    "⚡",
        "Session Trading":  "🕐",
        "SMC Order Block":  "📦",
        "Turtle Soup":      "🐢",
        "Kiss of Death":    "💀",
    }

    def format_alert(self, signal: TradeSignal, ml_score: int,
                      news_info: str, account_balance: float) -> str:
        """
        Builds the full alert message.
        Includes: setup summary, detailed reason, levels, risk info.
        """
        dir_emoji  = self.EMOJI_DIR.get(signal.direction, "⚪")
        strat_emoji = self.EMOJI_STRAT.get(signal.strategy_name, "📊")

        now_utc = datetime.now(tz=timezone.utc)
        now_ist = now_utc + timedelta(hours=5, minutes=30)

        risk_amount = account_balance * (RISK_PERCENT_PER_TRADE / 100)

        # Score bar
        score_bar = self._score_bar(ml_score)

        # Confluence checklist
        confluence_text = "\n".join([f"  ✅ {pt}" for pt in signal.confluence_points])

        message = f"""
{strat_emoji} {dir_emoji} *{signal.strategy_name.upper()} SIGNAL*
━━━━━━━━━━━━━━━━━━━━━━━━━━━

*{signal.direction} {signal.symbol}*
📅 {now_ist.strftime('%d %b %Y, %I:%M %p')} IST

━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 *TRADE LEVELS*

  Entry:      `{signal.entry_price:.5f}`
  Stop Loss:  `{signal.sl_price:.5f}`  (−{signal.sl_pips:.1f} pips)
  Take Profit: `{signal.tp_price:.5f}` (+{signal.tp_pips:.1f} pips)
  R:R Ratio:  *1:{signal.rr_ratio:.1f}*
  Lot Size:   {signal.lot_size:.2f} lots
  Risk:        ${risk_amount:.2f} ({RISK_PERCENT_PER_TRADE}% of balance)

━━━━━━━━━━━━━━━━━━━━━━━━━━━
🧠 *SIGNAL QUALITY*

{score_bar}
Score: *{ml_score}/100*  |  Session: {signal.session.replace('_', ' ').title()}

━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ *CONFLUENCE FACTORS*

{confluence_text}

━━━━━━━━━━━━━━━━━━━━━━━━━━━
📝 *DETAILED ANALYSIS*

{signal.detailed_reason}

━━━━━━━━━━━━━━━━━━━━━━━━━━━
📰 *NEWS CHECK*
{news_info}

━━━━━━━━━━━━━━━━━━━━━━━━━━━
🆔 Signal ID: `{signal.signal_id}`
⚠️ _Confirm within 3 minutes or signal expires._
""".strip()

        return message

    @staticmethod
    def _score_bar(score: int) -> str:
        filled = int(score / 10)
        empty  = 10 - filled
        bar    = "█" * filled + "░" * empty
        if score >= 80:
            label = "🔥 EXCELLENT"
        elif score >= 70:
            label = "✅ GOOD"
        elif score >= 60:
            label = "⚠️ MODERATE"
        else:
            label = "❗ WEAK"
        return f"`[{bar}]` {label}"


# ── Telegram handler ──────────────────────────────────────

class TelegramNotifier:
    """
    Sends trade alerts via Telegram with inline confirmation buttons.
    Listens for button presses and triggers order placement.
    """

    def __init__(self, order_callback: Callable):
        """
        order_callback(signal_id, confirmed: bool) → called when user taps button.
        """
        self.order_callback = order_callback
        self.pending_signals = {}   # signal_id → TradeSignal
        self.formatter = AlertFormatter()
        self.app = None

        if not TELEGRAM_AVAILABLE:
            logger.error("Telegram library not available.")
            return

        self.app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()
        self.app.add_handler(CallbackQueryHandler(self._handle_callback))
        self.app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,
                                             self._handle_text))

    async def send_alert(self, signal: TradeSignal, ml_score: int,
                          news_info: str, account_balance: float):
        """Sends the trade alert with BUY / SKIP buttons."""
        if not TELEGRAM_AVAILABLE:
            return

        message = self.formatter.format_alert(
            signal, ml_score, news_info, account_balance
        )

        keyboard = [
            [
                InlineKeyboardButton(
                    f"✅ {signal.direction}  |  {signal.lot_size:.2f} lots",
                    callback_data=f"confirm:{signal.signal_id}"
                ),
                InlineKeyboardButton(
                    "❌ SKIP",
                    callback_data=f"skip:{signal.signal_id}"
                ),
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)

        bot = Bot(token=TELEGRAM_BOT_TOKEN)
        try:
            msg = await bot.send_message(
                chat_id=TELEGRAM_CHAT_ID,
                text=message,
                parse_mode="Markdown",
                reply_markup=reply_markup,
            )
            self.pending_signals[signal.signal_id] = {
                "signal": signal, "message_id": msg.message_id,
                "expires_at": datetime.now(tz=timezone.utc) + timedelta(minutes=3),
            }
            logger.info(f"Telegram alert sent: {signal.signal_id}")
        except Exception as e:
            logger.error(f"Telegram send failed: {e}")

    async def _handle_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handles button press from Telegram inline keyboard."""
        query = update.callback_query
        await query.answer()

        data = query.data  # "confirm:XXXX" or "skip:XXXX"
        action, signal_id = data.split(":", 1)

        pending = self.pending_signals.get(signal_id)
        if not pending:
            await query.edit_message_text("⏱ Signal expired or already processed.")
            return

        # Check if expired
        if datetime.now(tz=timezone.utc) > pending["expires_at"]:
            await query.edit_message_text("⏱ Signal expired (3-minute window passed).")
            del self.pending_signals[signal_id]
            return

        signal = pending["signal"]
        confirmed = (action == "confirm")

        if confirmed:
            await query.edit_message_text(
                f"✅ Confirmed — placing {signal.direction} order on {signal.symbol}...\n"
                f"Entry: {signal.entry_price:.5f} | SL: {signal.sl_price:.5f} | TP: {signal.tp_price:.5f}"
            )
            result = self.order_callback(signal_id, True)
            if result and result.get("success"):
                await context.bot.send_message(
                    chat_id=TELEGRAM_CHAT_ID,
                    text=f"🎯 Order placed!\n"
                         f"Ticket: #{result.get('ticket')}\n"
                         f"Fill price: {result.get('price', signal.entry_price):.5f}\n"
                         f"Lot: {signal.lot_size:.2f}"
                )
            else:
                await context.bot.send_message(
                    chat_id=TELEGRAM_CHAT_ID,
                    text=f"❌ Order failed: {result.get('error', 'Unknown error')}"
                )
        else:
            await query.edit_message_text(f"❌ Skipped — {signal.symbol} {signal.direction}")
            self.order_callback(signal_id, False)

        del self.pending_signals[signal_id]

    async def _handle_text(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handles text commands like /status, /balance."""
        text = update.message.text.strip().upper()
        if text == "/STATUS":
            await update.message.reply_text(
                f"🤖 Bot is running\n"
                f"Monitoring: {', '.join(SYMBOLS[:4])}...\n"
                f"Pending signals: {len(self.pending_signals)}"
            )
        elif text == "/PENDING":
            if not self.pending_signals:
                await update.message.reply_text("No pending signals.")
            else:
                for sid, p in self.pending_signals.items():
                    sig = p["signal"]
                    await update.message.reply_text(
                        f"⏳ {sid}: {sig.direction} {sig.symbol} @ {sig.entry_price:.5f}"
                    )

    def start_polling(self):
        """Starts the Telegram bot polling loop (blocking). Run in a thread."""
        if self.app:
            self.app.run_polling(poll_interval=1.0)


# ── WhatsApp handler ──────────────────────────────────────

class WhatsAppNotifier:
    """
    Sends trade alerts via Twilio WhatsApp API.
    Confirmation via reply "YES" or "NO".
    (For full confirmation, run a Twilio webhook server
     or use the Telegram bot as primary confirmation.)
    """

    def __init__(self, order_callback: Callable):
        self.order_callback = order_callback
        self.pending_signals = {}
        self.formatter = AlertFormatter()
        self.client = None

        if not TWILIO_AVAILABLE:
            logger.error("Twilio not installed.")
            return

        try:
            self.client = TwilioClient(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        except Exception as e:
            logger.error(f"Twilio init failed: {e}")

    def send_alert(self, signal: TradeSignal, ml_score: int,
                    news_info: str, account_balance: float):
        """Send WhatsApp alert (text-based, confirmation via Telegram preferred)."""
        if not self.client:
            return

        message = self.formatter.format_alert(signal, ml_score, news_info, account_balance)

        # WhatsApp has length limits — truncate if needed
        wa_message = message[:1600]
        wa_message += (f"\n\n📲 *Reply YES to confirm, NO to skip.*\n"
                       f"Signal ID: {signal.signal_id}")

        try:
            self.client.messages.create(
                body=wa_message,
                from_=TWILIO_FROM_NUMBER,
                to=YOUR_WHATSAPP_NUMBER,
            )
            self.pending_signals[signal.signal_id] = signal
            logger.info(f"WhatsApp alert sent: {signal.signal_id}")
        except Exception as e:
            logger.error(f"WhatsApp send failed: {e}")

    def handle_reply(self, signal_id: str, reply: str):
        """
        Called when user replies YES/NO via WhatsApp webhook.
        Set up a Twilio webhook to call this.
        """
        signal = self.pending_signals.get(signal_id)
        if not signal:
            return

        confirmed = reply.strip().upper() in ("YES", "Y", "1", "BUY", "CONFIRM")
        self.order_callback(signal_id, confirmed)

        if signal_id in self.pending_signals:
            del self.pending_signals[signal_id]


# ── Combined notifier ─────────────────────────────────────

class NotificationManager:
    """
    Manages both Telegram and WhatsApp notifications.
    Sends to both simultaneously.
    Primary confirmation = Telegram (instant inline buttons).
    WhatsApp = backup / second channel.
    """

    def __init__(self, order_callback: Callable):
        self.order_callback = order_callback
        self.telegram = TelegramNotifier(order_callback) if TELEGRAM_AVAILABLE else None
        self.whatsapp = WhatsAppNotifier(order_callback) if TWILIO_AVAILABLE else None
        self.formatter = AlertFormatter()

    async def send_signal(self, signal: TradeSignal, ml_score: int,
                           news_info: str, account_balance: float):
        """Send alert to both channels."""
        # Telegram (async)
        if self.telegram:
            await self.telegram.send_alert(signal, ml_score, news_info, account_balance)

        # WhatsApp (sync, run in thread if needed)
        if self.whatsapp:
            self.whatsapp.send_alert(signal, ml_score, news_info, account_balance)

    def start_telegram_polling(self):
        """Start Telegram bot listener. Call in a separate thread."""
        if self.telegram and self.telegram.app:
            self.telegram.start_polling()
