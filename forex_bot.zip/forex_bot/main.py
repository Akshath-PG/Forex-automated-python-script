"""
=============================================================
  MAIN — BOT ORCHESTRATOR
  The central control loop. Runs continuously and coordinates:
    1. MT5 data feed
    2. Market structure analysis
    3. Strategy scanning (all 5 strategies)
    4. ML scoring
    5. News filtering
    6. Alert dispatch (Telegram + WhatsApp)
    7. Order placement after confirmation

  Run this file to start the bot:
    python main.py

  Run with --train flag to train the ML model first:
    python main.py --train
=============================================================
"""

import asyncio
import logging
import signal
import sys
import time
import threading
from datetime import datetime, timezone, timedelta
from typing import Optional

from config.settings import *
from core.mt5_handler import MT5Handler
from core.market_structure import MarketStructureAnalyser
from core.ltf_confirmation import LTFConfirmationEngine
from core.news_filter import NewsFilter
from strategies.all_strategies import (
    SilverBulletStrategy, SessionTradingStrategy,
    SMCOrderBlockStrategy, TurtleSoupStrategy, KissOfDeathStrategy,
    TradeSignal,
)
from ml.model import LiveScorer
from notifications.notifier import NotificationManager

# ── Logging setup ─────────────────────────────────────────
import os
os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler(sys.stdout),
    ]
)
logger = logging.getLogger("ForexBot")


# ── Scan interval (seconds) ───────────────────────────────
SCAN_INTERVAL = 60   # scan every 60 seconds


class ForexBot:
    """
    Main bot class. Runs a continuous scan loop across all
    configured symbols and strategies.
    """

    def __init__(self):
        # Core components
        self.mt5      = MT5Handler()
        self.news     = NewsFilter()
        self.ltf      = None  # created after mt5 connects
        self.analyser = None
        self.scorer   = LiveScorer()

        # Strategies (initialised after MT5 connects)
        self.strategies = []

        # Signal deduplication: don't re-alert same setup
        self._recent_signals = {}   # signal_id → timestamp
        self._signal_cooldown = {}  # symbol → last_signal_time
        self.COOLDOWN_MINUTES = 15  # minimum gap between signals for same symbol

        # Pending signals awaiting user confirmation
        self._pending_orders = {}   # signal_id → TradeSignal

        # Notification manager (set up with order callback)
        self.notifier = NotificationManager(order_callback=self._handle_confirmation)

        # Running flag
        self._running = False

    # ── Startup ───────────────────────────────────────────

    def start(self):
        """Main entry point. Connects to MT5 and starts the scan loop."""
        logger.info("=" * 60)
        logger.info("  FOREX BOT — STARTING UP")
        logger.info(f"  Symbols:    {', '.join(SYMBOLS)}")
        logger.info(f"  Strategies: {[k for k, v in STRATEGIES_ENABLED.items() if v]}")
        logger.info(f"  Min RR:     1:{MIN_RR_RATIO}")
        logger.info(f"  Min Score:  {MIN_CONFLUENCE_SCORE}")
        logger.info("=" * 60)

        # Connect to MT5
        if not self.mt5.connect():
            logger.error("Failed to connect to MT5 — exiting.")
            return

        # Init components that need MT5
        self.ltf      = LTFConfirmationEngine(self.mt5)
        self.analyser = MarketStructureAnalyser(self.mt5)
        self.strategies = self._build_strategies()

        # Start Telegram polling in a background thread
        telegram_thread = threading.Thread(
            target=self.notifier.start_telegram_polling, daemon=True
        )
        telegram_thread.start()
        logger.info("Telegram bot polling started.")

        # Main scan loop
        self._running = True
        self._scan_loop()

    def _build_strategies(self):
        strats = []
        cfg = STRATEGIES_ENABLED
        if cfg.get("silver_bullet"):   strats.append(SilverBulletStrategy(self.mt5, self.ltf))
        if cfg.get("session_trading"):  strats.append(SessionTradingStrategy(self.mt5, self.ltf))
        if cfg.get("smc_ob"):           strats.append(SMCOrderBlockStrategy(self.mt5, self.ltf))
        if cfg.get("turtle_soup"):      strats.append(TurtleSoupStrategy(self.mt5, self.ltf))
        if cfg.get("kiss_of_death"):    strats.append(KissOfDeathStrategy(self.mt5, self.ltf))
        return strats

    def stop(self, *args):
        logger.info("Shutdown signal received.")
        self._running = False
        self.mt5.disconnect()

    # ── Main scan loop ────────────────────────────────────

    def _scan_loop(self):
        """Runs indefinitely, scanning all symbols every SCAN_INTERVAL seconds."""
        logger.info("Scan loop started.")
        while self._running:
            start_time = time.time()
            try:
                self._scan_all()
            except Exception as e:
                logger.error(f"Scan error: {e}", exc_info=True)

            elapsed = time.time() - start_time
            sleep_time = max(0, SCAN_INTERVAL - elapsed)
            logger.debug(f"Scan completed in {elapsed:.1f}s. Next scan in {sleep_time:.0f}s.")
            time.sleep(sleep_time)

    def _scan_all(self):
        """Scans all symbols across all strategies."""
        now_utc = datetime.now(tz=timezone.utc)
        now_ist = now_utc + timedelta(hours=5, minutes=30)
        logger.info(f"── Scanning {len(SYMBOLS)} symbols at {now_ist.strftime('%H:%M')} IST ──")

        # Check max concurrent trades
        open_trades = self.mt5.get_open_trades_count()
        if open_trades >= MAX_CONCURRENT_TRADES:
            logger.info(f"Max concurrent trades reached ({open_trades}/{MAX_CONCURRENT_TRADES}) — skipping scan.")
            return

        for symbol in SYMBOLS:
            try:
                self._scan_symbol(symbol)
            except Exception as e:
                logger.error(f"Error scanning {symbol}: {e}", exc_info=False)

    def _scan_symbol(self, symbol: str):
        """Runs all strategies on a single symbol."""
        # Check spread
        spread = self.mt5.get_spread_pips(symbol)
        if spread > MAX_SPREAD_PIPS:
            logger.debug(f"{symbol}: spread {spread:.1f} pips > max {MAX_SPREAD_PIPS} — skipping")
            return

        # Check cooldown
        if not self._check_cooldown(symbol):
            return

        # Check news block
        blocked, news_reason = self.news.is_blocked(symbol)
        if blocked:
            logger.info(f"{symbol}: {news_reason}")
            return

        # Load candles (all timeframes at once)
        candles = self.mt5.get_multi_tf(symbol)
        if not candles.get("H1", None) is not None and len(candles.get("H1", [])) < 50:
            logger.warning(f"{symbol}: insufficient candle data")
            return

        # Market structure analysis
        ms = self.analyser.analyse(symbol, candles)
        logger.debug(f"{symbol}: HTF={ms.htf_trend} | MTF={ms.mtf_trend} | Bias={ms.bias}")

        # Run each strategy
        for strategy in self.strategies:
            if not STRATEGIES_ENABLED.get(strategy.name.lower().replace(" ", "_"), True):
                continue
            try:
                signal = strategy.scan(symbol, ms, candles)
                if signal:
                    self._process_signal(signal, ms, candles)
            except Exception as e:
                logger.error(f"{symbol} — {strategy.name}: {e}", exc_info=False)

    # ── Signal processing ─────────────────────────────────

    def _process_signal(self, signal: TradeSignal, ms, candles: dict):
        """
        Pipeline after a strategy generates a signal:
        1. Check RR meets minimum
        2. ML score the setup
        3. Check minimum confluence score
        4. Compute lot size
        5. Send alert
        """
        logger.info(f"Signal: {signal.strategy_name} | {signal.direction} {signal.symbol} "
                    f"| RR={signal.rr_ratio:.1f} | Score={signal.confidence_score}")

        # RR check
        if signal.rr_ratio < MIN_RR_RATIO:
            logger.info(f"  → RR {signal.rr_ratio:.1f} < {MIN_RR_RATIO} minimum — skipped")
            return

        # Build ML scoring record
        score_record = self._build_score_record(signal, ms, candles)
        final_score  = self.scorer.score(score_record)

        if final_score < MIN_CONFLUENCE_SCORE:
            logger.info(f"  → Score {final_score} < {MIN_CONFLUENCE_SCORE} minimum — skipped")
            return

        # Lot size
        signal.lot_size = self.mt5.calculate_lot_size(signal.symbol, signal.sl_pips)

        # News info for alert
        news_info = self.news.format_news_warning(signal.symbol)

        # Account balance for risk display
        balance = self.mt5.get_account_balance()

        # Store pending order
        self._pending_orders[signal.signal_id] = signal

        # Set cooldown
        self._signal_cooldown[signal.symbol] = datetime.now(tz=timezone.utc)

        # Send alert (run async in event loop)
        asyncio.run(
            self.notifier.send_signal(signal, final_score, news_info, balance)
        )

        logger.info(f"  → Alert sent | Score={final_score} | Lot={signal.lot_size:.2f}")

    def _build_score_record(self, signal: TradeSignal, ms, candles: dict) -> dict:
        """Assembles the feature record for ML scoring."""
        m5 = candles.get("M5", None)
        volume_ratio = 1.0
        body_ratio = upper_wick_ratio = lower_wick_ratio = 0.5

        if m5 is not None and len(m5) > 5:
            last = m5.iloc[-1]
            rng  = last['high'] - last['low']
            vols = m5['tick_volume'].values
            volume_ratio = float(vols[-1]) / max(float(vols[-20:].mean()), 1)
            body_ratio = abs(last['close'] - last['open']) / max(rng, 0.00001)
            upper_wick_ratio = (last['high'] - max(last['open'], last['close'])) / max(rng, 0.00001)
            lower_wick_ratio = (min(last['open'], last['close']) - last['low']) / max(rng, 0.00001)

        best_ob  = vars(ms.order_blocks[0])  if ms.order_blocks  else None
        best_fvg = vars(ms.fvgs[0])          if ms.fvgs          else None

        return {
            "timestamp":       signal.timestamp,
            "symbol":          signal.symbol,
            "direction":       signal.direction,
            "htf_trend":       ms.htf_trend,
            "mtf_trend":       ms.mtf_trend,
            "last_bos":        ms.last_bos,
            "entry_price":     signal.entry_price,
            "rr_ratio":        signal.rr_ratio,
            "strategy_name":   signal.strategy_name,
            "confidence_score": signal.confidence_score,
            "best_ob":         best_ob,
            "best_fvg":        best_fvg,
            "fvg_at_ob":       0,
            "atr_pips":        signal.sl_pips / 1.5,
            "spread_pips":     self.mt5.get_spread_pips(signal.symbol),
            "volume_ratio":    volume_ratio,
            "body_ratio":      body_ratio,
            "upper_wick_ratio": upper_wick_ratio,
            "lower_wick_ratio": lower_wick_ratio,
            "confluence_count": len(signal.confluence_points),
        }

    # ── Order confirmation ────────────────────────────────

    def _handle_confirmation(self, signal_id: str, confirmed: bool) -> dict:
        """
        Called by the Telegram/WhatsApp handler when user confirms or skips.
        Places the order if confirmed.
        Returns the MT5 order result dict.
        """
        signal = self._pending_orders.get(signal_id)
        if not signal:
            logger.warning(f"Confirmation for unknown signal: {signal_id}")
            return {"success": False, "error": "Signal not found"}

        if not confirmed:
            logger.info(f"Signal {signal_id} SKIPPED by user.")
            del self._pending_orders[signal_id]
            return {"success": False, "error": "Skipped by user"}

        logger.info(f"Signal {signal_id} CONFIRMED — placing order...")

        result = self.mt5.place_order(
            symbol    = signal.symbol,
            direction = signal.direction,
            entry     = signal.entry_price,
            sl        = signal.sl_price,
            tp        = signal.tp_price,
            lot       = signal.lot_size,
            comment   = f"Bot_{signal.strategy_name[:10]}_{signal.signal_id}",
        )

        if result.get("success"):
            logger.info(f"✅ Order placed — Ticket #{result.get('ticket')} "
                        f"| {signal.direction} {signal.lot_size} {signal.symbol} "
                        f"@ {result.get('price')}")
            self._log_trade(signal, result)
        else:
            logger.error(f"❌ Order failed: {result.get('error')}")

        del self._pending_orders[signal_id]
        return result

    # ── Utilities ─────────────────────────────────────────

    def _check_cooldown(self, symbol: str) -> bool:
        last = self._signal_cooldown.get(symbol)
        if last is None:
            return True
        elapsed = (datetime.now(tz=timezone.utc) - last).total_seconds() / 60
        if elapsed < self.COOLDOWN_MINUTES:
            logger.debug(f"{symbol}: cooldown {elapsed:.0f}/{self.COOLDOWN_MINUTES} min")
            return False
        return True

    def _log_trade(self, signal: TradeSignal, result: dict):
        """Appends trade to CSV log for performance tracking."""
        import csv
        log_path = "data/trade_log.csv"
        now_ist = datetime.now(tz=timezone.utc) + timedelta(hours=5, minutes=30)
        row = {
            "date":       now_ist.strftime("%Y-%m-%d"),
            "time_ist":   now_ist.strftime("%H:%M"),
            "symbol":     signal.symbol,
            "strategy":   signal.strategy_name,
            "direction":  signal.direction,
            "entry":      signal.entry_price,
            "sl":         signal.sl_price,
            "tp":         signal.tp_price,
            "sl_pips":    signal.sl_pips,
            "tp_pips":    signal.tp_pips,
            "rr":         signal.rr_ratio,
            "lot":        signal.lot_size,
            "ticket":     result.get("ticket", ""),
            "score":      signal.confidence_score,
            "session":    signal.session,
            "htf_trend":  signal.htf_trend,
            "ltf_pattern": signal.ltf_pattern,
            "signal_id":  signal.signal_id,
        }
        write_header = not os.path.exists(log_path)
        with open(log_path, "a", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(row.keys()))
            if write_header:
                writer.writeheader()
            writer.writerow(row)


# ── Entry point ───────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Forex Trading Bot")
    parser.add_argument("--train", action="store_true",
                        help="Download 4y of data and train the ML model before starting")
    args = parser.parse_args()

    if args.train:
        logger.info("Starting ML training pipeline...")
        from ml.model import run_training
        run_training()
        logger.info("Training complete. Starting bot...")

    bot = ForexBot()

    # Graceful shutdown on Ctrl+C
    signal.signal(signal.SIGINT,  bot.stop)
    signal.signal(signal.SIGTERM, bot.stop)

    bot.start()
