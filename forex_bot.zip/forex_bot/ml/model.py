"""
=============================================================
  ML — MODEL TRAINER & SCORER
  Trains a LightGBM model on 4 years of historical setups.
  The model is a FILTER — it scores quality of already
  rule-confirmed setups. It never generates signals alone.

  Training pipeline:
    1. Download 4 years of OHLCV for all symbols
    2. Run all strategy rules on historical data (replay)
    3. For each triggered signal, record 35 features
    4. Label: 1 if TP hit before SL, 0 if SL hit first
    5. Train LightGBM with careful overfitting controls
    6. Save model + scaler for live scoring

  Features (35 total):
    - Session category, hour, day of week
    - HTF/MTF trend alignment score
    - OB strength, OB age, OB impulse ATR
    - FVG size, FVG age
    - ATR at signal time, spread pips
    - Confluence count (how many sub-signals aligned)
    - Distance from price to OB/FVG in pips
    - Prior candle body/wick ratio
    - Volume ratio (current vs 20-bar average)
    - News proximity (minutes to next event)
    - Strategy type (one-hot)
    - Win rate of same setup in last 20 trades (rolling)
=============================================================
"""

import os, sys, pickle, logging
import numpy as np
import pandas as pd
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.settings import *

logger = logging.getLogger(__name__)

try:
    import lightgbm as lgb
    from sklearn.model_selection import TimeSeriesSplit
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import classification_report, roc_auc_score
    ML_AVAILABLE = True
except ImportError:
    ML_AVAILABLE = False
    logger.warning("LightGBM / sklearn not installed. ML scoring will use rule-based fallback.")


# ── Feature engineering ───────────────────────────────────

class FeatureEngineer:
    """
    Extracts the 35 features from a live or historical setup.
    Same feature set at train time AND inference time.
    """

    FEATURE_NAMES = [
        # Time features
        "hour_sin", "hour_cos", "dow_sin", "dow_cos",
        # Session
        "is_london_open", "is_ny_open", "is_overlap", "is_asian",
        # Trend alignment
        "htf_bullish", "htf_bearish", "mtf_bullish", "mtf_bearish",
        "trend_aligned",          # 1 if HTF and MTF match
        # Structure
        "has_bos", "bos_aligned",
        # OB features
        "ob_strength",            # 0-100
        "ob_age_candles",         # age in candles
        "ob_impulse_atr",         # impulse size in ATR multiples
        "ob_mitigated",           # 0 or 1
        "price_at_ob_pct",        # how deep into OB price is (0=top, 1=bottom)
        # FVG features
        "has_fvg",
        "fvg_size_pips",
        "fvg_age_candles",
        "fvg_at_ob",              # 1 if FVG overlaps OB
        # Market conditions
        "atr_pips",               # ATR in pips at signal time
        "spread_pips",
        "volume_ratio",           # current vol / 20-bar avg
        "body_ratio",             # body / total range of trigger candle
        "upper_wick_ratio",
        "lower_wick_ratio",
        # Confluence
        "confluence_count",       # number of aligned factors
        "min_rr_met",             # 1 if >= 1:2 RR
        # Strategy type
        "strat_silver_bullet",
        "strat_session",
        "strat_smc_ob",
        "strat_turtle_soup",
        "strat_kiss_of_death",
    ]

    def extract(self, signal_record: dict) -> np.ndarray:
        """
        signal_record contains all context at time of signal.
        Returns a 1D numpy array of feature values.
        """
        now = signal_record.get("timestamp", datetime.now(tz=timezone.utc))
        hour = now.hour + now.minute / 60
        dow  = now.weekday()

        f = {}

        # Cyclic time encoding
        f["hour_sin"] = np.sin(2 * np.pi * hour / 24)
        f["hour_cos"] = np.cos(2 * np.pi * hour / 24)
        f["dow_sin"]  = np.sin(2 * np.pi * dow / 7)
        f["dow_cos"]  = np.cos(2 * np.pi * dow / 7)

        # Session
        f["is_london_open"] = 1 if 7  <= hour < 9  else 0
        f["is_ny_open"]     = 1 if 12 <= hour < 15 else 0
        f["is_overlap"]     = 1 if 12 <= hour < 16 else 0
        f["is_asian"]       = 1 if hour < 7         else 0

        # Trend
        htf = signal_record.get("htf_trend", "ranging")
        mtf = signal_record.get("mtf_trend", "ranging")
        direction = signal_record.get("direction", "BUY")

        f["htf_bullish"]  = 1 if htf == "bullish" else 0
        f["htf_bearish"]  = 1 if htf == "bearish" else 0
        f["mtf_bullish"]  = 1 if mtf == "bullish" else 0
        f["mtf_bearish"]  = 1 if mtf == "bearish" else 0
        f["trend_aligned"] = 1 if htf == mtf and htf != "ranging" else 0

        # Structure
        bos = signal_record.get("last_bos")
        f["has_bos"]    = 1 if bos else 0
        f["bos_aligned"] = 1 if (bos == "bullish" and direction == "BUY") or \
                                 (bos == "bearish" and direction == "SELL") else 0

        # OB
        ob = signal_record.get("best_ob")
        if ob:
            f["ob_strength"]    = ob.get("strength", 0) / 100
            f["ob_age_candles"] = min(ob.get("candles_ago", 50), 50) / 50
            f["ob_impulse_atr"] = min(ob.get("impulse_size_atr", 0), 5) / 5
            f["ob_mitigated"]   = 1 if ob.get("mitigated") else 0
            entry = signal_record.get("entry_price", 0)
            ob_range = ob.get("high", 1) - ob.get("low", 0)
            if ob_range > 0:
                f["price_at_ob_pct"] = (ob.get("high", entry) - entry) / ob_range
            else:
                f["price_at_ob_pct"] = 0.5
        else:
            f["ob_strength"] = f["ob_age_candles"] = f["ob_impulse_atr"] = 0
            f["ob_mitigated"] = 0
            f["price_at_ob_pct"] = 0.5

        # FVG
        fvg = signal_record.get("best_fvg")
        if fvg:
            f["has_fvg"]       = 1
            f["fvg_size_pips"] = min(fvg.get("size_pips", 0), 20) / 20
            f["fvg_age_candles"] = min(fvg.get("candles_ago", 30), 30) / 30
            f["fvg_at_ob"]     = signal_record.get("fvg_at_ob", 0)
        else:
            f["has_fvg"] = f["fvg_size_pips"] = f["fvg_age_candles"] = f["fvg_at_ob"] = 0

        # Market conditions
        f["atr_pips"]     = min(signal_record.get("atr_pips", 10), 50) / 50
        f["spread_pips"]  = min(signal_record.get("spread_pips", 2), 10) / 10
        f["volume_ratio"] = min(signal_record.get("volume_ratio", 1.0), 3.0) / 3.0
        f["body_ratio"]   = signal_record.get("body_ratio", 0.5)
        f["upper_wick_ratio"] = signal_record.get("upper_wick_ratio", 0.25)
        f["lower_wick_ratio"] = signal_record.get("lower_wick_ratio", 0.25)

        # Confluence
        f["confluence_count"] = min(signal_record.get("confluence_count", 0), 8) / 8
        f["min_rr_met"] = 1 if signal_record.get("rr_ratio", 0) >= MIN_RR_RATIO else 0

        # Strategy one-hot
        strat = signal_record.get("strategy_name", "")
        f["strat_silver_bullet"]  = 1 if "Silver Bullet"   in strat else 0
        f["strat_session"]        = 1 if "Session"         in strat else 0
        f["strat_smc_ob"]         = 1 if "Order Block"     in strat else 0
        f["strat_turtle_soup"]    = 1 if "Turtle Soup"     in strat else 0
        f["strat_kiss_of_death"]  = 1 if "Kiss of Death"   in strat else 0

        return np.array([f[k] for k in self.FEATURE_NAMES])


# ── Historical replay ─────────────────────────────────────

class HistoricalReplayer:
    """
    Replays 4 years of bar data and generates a labelled
    dataset by running the strategy rules bar-by-bar.
    This is the training data generator.
    """

    def __init__(self, mt5_handler):
        self.mt5 = mt5_handler
        self.fe  = FeatureEngineer()

    def generate_dataset(self, symbols: list) -> pd.DataFrame:
        """
        For each symbol, download 4 years of data and replay.
        Returns a DataFrame with feature columns + label column.
        """
        all_records = []

        for symbol in symbols:
            logger.info(f"Replaying history for {symbol}...")

            # Download all timeframes
            h4_hist  = self.mt5.download_history(symbol, "H4",  years=4)
            h1_hist  = self.mt5.download_history(symbol, "H1",  years=4)
            m15_hist = self.mt5.download_history(symbol, "M15", years=4)
            m5_hist  = self.mt5.download_history(symbol, "M5",  years=4)

            if len(h1_hist) < 200:
                logger.warning(f"Insufficient H1 data for {symbol} — skipping")
                continue

            # Align all TFs to H1 timestamps
            records = self._replay_symbol(
                symbol, h4_hist, h1_hist, m15_hist, m5_hist
            )
            all_records.extend(records)
            logger.info(f"{symbol}: {len(records)} labeled setups generated")

        if not all_records:
            logger.error("No training records generated!")
            return pd.DataFrame()

        df = pd.DataFrame(all_records)
        logger.info(f"Total training records: {len(df)} | Win rate: {df['label'].mean():.2%}")
        return df

    def _replay_symbol(self, symbol, h4, h1, m15, m5) -> list:
        """Walk forward through H1 bars, detect setups, label them."""
        from core.market_structure import MarketStructureAnalyser
        records = []
        pip_size = self.mt5.get_pip_size(symbol)

        # We need at least 100 bars of lookback before we start labelling
        start_idx = 100

        for i in range(start_idx, len(h1) - 50):
            ts = h1.index[i]

            # Slice all TFs up to current bar (no lookahead)
            h4_slice  = h4[h4.index <= ts].tail(200)
            h1_slice  = h1.iloc[:i + 1].tail(200)
            m15_slice = m15[m15.index <= ts].tail(300)
            m5_slice  = m5[m5.index <= ts].tail(200)

            if len(h4_slice) < 30 or len(m15_slice) < 20:
                continue

            # Check for basic setup conditions (simplified replay)
            record = self._check_setup(
                symbol, ts, h4_slice, h1_slice, m15_slice, m5_slice,
                h1, pip_size, i
            )
            if record:
                records.append(record)

        return records

    def _check_setup(self, symbol, ts, h4, h1, m15, m5,
                     full_h1, pip_size, current_idx) -> dict:
        """
        Simplified setup detection for training.
        Returns a record dict if a valid setup was found, else None.
        """
        try:
            atr = h1['atr'].iloc[-1] if 'atr' in h1.columns else 0.001
            if np.isnan(atr) or atr == 0:
                return None

            closes = h1['close'].values
            highs  = h1['high'].values
            lows   = h1['low'].values

            # Quick HTF trend check
            if len(h4) < 10:
                return None
            h4_closes = h4['close'].values
            htf_trend = "bullish" if h4_closes[-1] > h4_closes[-20] else "bearish"
            mtf_trend = "bullish" if closes[-1] > closes[-20] else "bearish"

            direction = "BUY" if htf_trend == "bullish" else "SELL"

            # Find OB in last 30 candles
            ob_idx = None
            for j in range(max(0, len(h1) - 30), len(h1) - 2):
                impulse = abs(closes[j + 1] - closes[j])
                if impulse < OB_MIN_IMPULSE_ATR_MULT * atr:
                    continue
                if direction == "BUY" and closes[j] < h1['open'].values[j]:  # bearish OB
                    ob_idx = j
                    break
                if direction == "SELL" and closes[j] > h1['open'].values[j]:  # bullish OB
                    ob_idx = j
                    break

            if ob_idx is None:
                return None

            ob_high = highs[ob_idx]
            ob_low  = lows[ob_idx]
            price   = closes[-1]

            # Price must be near OB
            if direction == "BUY" and not (ob_low <= price <= ob_high * 1.005):
                return None
            if direction == "SELL" and not (ob_low * 0.995 <= price <= ob_high):
                return None

            # Impulse atr
            impulse_atr = abs(closes[ob_idx + 1] - closes[ob_idx]) / atr

            # Compute SL / TP for labelling
            if direction == "BUY":
                sl = ob_low - atr * 0.5
                tp = price + (price - sl) * MIN_RR_RATIO
            else:
                sl = ob_high + atr * 0.5
                tp = price - (sl - price) * MIN_RR_RATIO

            # Label: look forward 50 bars to see what hit first
            future = full_h1.iloc[current_idx + 1: current_idx + 51]
            label = self._compute_label(direction, tp, sl,
                                        future['high'].values, future['low'].values)
            if label is None:
                return None  # neither TP nor SL hit in 50 bars

            # Volume ratio
            vols = h1['tick_volume'].values
            vol_ratio = vols[-1] / max(np.mean(vols[-20:]), 1)

            # Body features
            last_c = h1.iloc[-1]
            rng = last_c['high'] - last_c['low']
            body = abs(last_c['close'] - last_c['open'])
            uw   = last_c['high'] - max(last_c['open'], last_c['close'])
            lw   = min(last_c['open'], last_c['close']) - last_c['low']

            return {
                "timestamp":      ts,
                "symbol":         symbol,
                "direction":      direction,
                "htf_trend":      htf_trend,
                "mtf_trend":      mtf_trend,
                "last_bos":       htf_trend,
                "entry_price":    price,
                "rr_ratio":       MIN_RR_RATIO,
                "strategy_name":  "SMC Order Block",
                "best_ob": {
                    "high": ob_high, "low": ob_low,
                    "strength": min(100, impulse_atr * 20),
                    "candles_ago": len(h1) - 1 - ob_idx,
                    "impulse_size_atr": impulse_atr,
                    "mitigated": False,
                },
                "best_fvg":       None,
                "fvg_at_ob":      0,
                "atr_pips":       atr / pip_size,
                "spread_pips":    2.0,
                "volume_ratio":   vol_ratio,
                "body_ratio":     body / max(rng, 0.00001),
                "upper_wick_ratio": uw / max(rng, 0.00001),
                "lower_wick_ratio": lw / max(rng, 0.00001),
                "confluence_count": 3,
                "label":          label,
            }
        except Exception as e:
            return None

    @staticmethod
    def _compute_label(direction, tp, sl, future_highs, future_lows):
        for h, l in zip(future_highs, future_lows):
            if direction == "BUY":
                if h >= tp:
                    return 1
                if l <= sl:
                    return 0
            else:
                if l <= tp:
                    return 1
                if h >= sl:
                    return 0
        return None


# ── Model trainer ─────────────────────────────────────────

class ModelTrainer:
    """
    Trains LightGBM on the labelled historical dataset.
    Uses TimeSeriesSplit to prevent data leakage.
    Anti-overfitting measures built in.
    """

    def __init__(self):
        self.fe = FeatureEngineer()
        Path("ml").mkdir(exist_ok=True)

    def train(self, df: pd.DataFrame):
        if not ML_AVAILABLE:
            logger.error("LightGBM not installed — cannot train.")
            return

        if len(df) < 500:
            logger.error(f"Only {len(df)} training records — need at least 500.")
            return

        logger.info(f"Training on {len(df)} records | "
                    f"Win rate: {df['label'].mean():.2%}")

        # Build feature matrix
        X = np.array([
            self.fe.extract(row.to_dict())
            for _, row in df.iterrows()
        ])
        y = df['label'].values

        # Scale
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)

        # TimeSeriesSplit — respects temporal order, no future leakage
        tscv = TimeSeriesSplit(n_splits=5)

        # LightGBM params — tuned to prevent overfitting
        params = {
            "objective":        "binary",
            "metric":           "auc",
            "learning_rate":    0.03,         # low LR = less overfit
            "num_leaves":       15,           # small tree = high bias, low variance
            "max_depth":        4,
            "min_child_samples": 50,          # each leaf needs 50+ samples
            "feature_fraction": 0.7,          # use 70% of features per tree
            "bagging_fraction": 0.8,
            "bagging_freq":     5,
            "reg_alpha":        0.1,          # L1 regularization
            "reg_lambda":       0.2,          # L2 regularization
            "n_estimators":     500,
            "verbose":          -1,
            "is_unbalance":     True,         # handle class imbalance
            "random_state":     42,
        }

        auc_scores = []
        model = None

        for fold, (train_idx, val_idx) in enumerate(tscv.split(X_scaled)):
            X_tr, X_val = X_scaled[train_idx], X_scaled[val_idx]
            y_tr, y_val = y[train_idx], y[val_idx]

            model = lgb.LGBMClassifier(**params)
            model.fit(
                X_tr, y_tr,
                eval_set=[(X_val, y_val)],
                callbacks=[
                    lgb.early_stopping(50, verbose=False),
                    lgb.log_evaluation(period=-1),
                ]
            )
            preds = model.predict_proba(X_val)[:, 1]
            auc   = roc_auc_score(y_val, preds)
            auc_scores.append(auc)
            logger.info(f"Fold {fold + 1}: AUC = {auc:.4f}")

        logger.info(f"Mean CV AUC: {np.mean(auc_scores):.4f} ± {np.std(auc_scores):.4f}")

        # Final model on all data
        final_model = lgb.LGBMClassifier(**params)
        final_model.fit(X_scaled, y)

        # Save
        with open(MODEL_PATH,   "wb") as f: pickle.dump(final_model, f)
        with open(SCALER_PATH,  "wb") as f: pickle.dump(scaler, f)
        with open(FEATURES_PATH, "wb") as f: pickle.dump(FeatureEngineer.FEATURE_NAMES, f)

        logger.info(f"Model saved to {MODEL_PATH}")

        # Feature importance
        importance = pd.Series(
            final_model.feature_importances_,
            index=FeatureEngineer.FEATURE_NAMES
        ).sort_values(ascending=False)
        logger.info(f"\nTop 10 features:\n{importance.head(10)}")


# ── Live scorer ───────────────────────────────────────────

class LiveScorer:
    """
    Loads the trained model and scores incoming signals.
    Falls back to rule-based scoring if model not available.
    """

    def __init__(self):
        self.model  = None
        self.scaler = None
        self.fe     = FeatureEngineer()
        self._load()

    def _load(self):
        try:
            if os.path.exists(MODEL_PATH) and os.path.exists(SCALER_PATH):
                with open(MODEL_PATH, "rb")  as f: self.model  = pickle.load(f)
                with open(SCALER_PATH, "rb") as f: self.scaler = pickle.load(f)
                logger.info("ML model loaded successfully.")
            else:
                logger.warning("No trained model found — using rule-based scoring only.")
        except Exception as e:
            logger.error(f"Failed to load model: {e}")

    def score(self, signal_record: dict) -> int:
        """
        Returns a score 0-100.
        Blends ML probability (if available) with rule-based score.
        """
        rule_score = signal_record.get("confidence_score", 50)

        if self.model is None or self.scaler is None:
            return rule_score

        try:
            features = self.fe.extract(signal_record)
            features_scaled = self.scaler.transform(features.reshape(1, -1))
            prob = self.model.predict_proba(features_scaled)[0][1]  # P(win)
            ml_score = int(prob * 100)

            # Blend: 60% rule-based, 40% ML
            blended = int(RULE_SCORE_WEIGHT * rule_score + ML_SCORE_WEIGHT * ml_score)
            logger.debug(f"Score — Rule: {rule_score} | ML: {ml_score} | Blended: {blended}")
            return min(100, blended)
        except Exception as e:
            logger.error(f"ML scoring error: {e}")
            return rule_score


# ── Entry point ───────────────────────────────────────────

def run_training():
    """
    Full training pipeline. Call this once to train the model.
    Requires MT5 connection.
    """
    from core.mt5_handler import MT5Handler
    mt5 = MT5Handler()
    if not mt5.connect():
        print("Cannot connect to MT5 — training aborted.")
        return

    replayer = HistoricalReplayer(mt5)
    df = replayer.generate_dataset(SYMBOLS)

    if df.empty:
        print("No training data generated — check MT5 connection and symbols.")
        return

    # Save raw dataset
    df.to_csv("data/training_data.csv", index=False)
    logger.info(f"Training data saved to data/training_data.csv")

    trainer = ModelTrainer()
    trainer.train(df)
    mt5.disconnect()
    print("Training complete.")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s %(levelname)s %(message)s')
    run_training()
