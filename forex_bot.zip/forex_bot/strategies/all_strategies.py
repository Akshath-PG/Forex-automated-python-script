"""
=============================================================
  STRATEGIES — ALL FIVE TRADING SETUPS
  Each strategy is a self-contained class with a .scan()
  method that returns a TradeSignal or None.

  Strategies defined here:
    1. Silver Bullet (ICT) — time-based FVG entry
    2. Session Trading — kill zone displacement + OB
    3. SMC / Order Block — OB retest with confluence
    4. Turtle Soup — false breakout reversal
    5. Kiss of Death — OB retest + BOS + rejection

  All strategies follow this logic flow:
    Step 1: Check time / session filter
    Step 2: Confirm HTF/MTF bias alignment
    Step 3: Identify the key level (OB, FVG, sweep point)
    Step 4: Require LTF confirmation (M5/M1)
    Step 5: Compute entry, SL, TP and reason text
=============================================================
"""

import pandas as pd
import numpy as np
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional, List
import os, sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.settings import *
from core.market_structure import (MarketStructure, MarketStructureAnalyser,
                                    OrderBlock, FairValueGap,
                                    is_in_silver_bullet_window, get_current_session)
from core.ltf_confirmation import LTFConfirmationEngine, get_fib_levels

logger = logging.getLogger(__name__)


# ── Signal output ─────────────────────────────────────────

@dataclass
class TradeSignal:
    symbol: str
    strategy_name: str
    direction: str               # 'BUY' or 'SELL'
    entry_price: float
    sl_price: float
    tp_price: float
    sl_pips: float
    tp_pips: float
    rr_ratio: float
    confidence_score: int        # 0-100
    confluence_points: List[str] # list of reasons as bullet strings
    detailed_reason: str         # full narrative for the alert
    ltf_pattern: str
    session: str
    htf_trend: str
    timestamp: datetime = field(default_factory=lambda: datetime.now(tz=timezone.utc))
    lot_size: float = 0.01
    signal_id: str = ""

    def __post_init__(self):
        import uuid
        if not self.signal_id:
            self.signal_id = str(uuid.uuid4())[:8].upper()


# ── Base class ────────────────────────────────────────────

class BaseStrategy:
    name = "Base"

    def __init__(self, mt5_handler, ltf_engine: LTFConfirmationEngine):
        self.mt5 = mt5_handler
        self.ltf = ltf_engine

    def scan(self, symbol: str, ms: MarketStructure,
             candles: dict) -> Optional[TradeSignal]:
        raise NotImplementedError

    def _pip_size(self, symbol):
        return self.mt5.get_pip_size(symbol)

    def _to_pips(self, price_diff, symbol):
        return abs(price_diff) / max(self._pip_size(symbol), 0.00001)


# ══════════════════════════════════════════════════════════
# STRATEGY 1 — SILVER BULLET (ICT)
# ══════════════════════════════════════════════════════════

class SilverBulletStrategy(BaseStrategy):
    """
    The ICT Silver Bullet is a time-of-day precision entry model.

    SETUP RULES (strictly defined):
    ──────────────────────────────
    Time windows (UTC):
      • 03:00–04:00 (London 10–11am)
      • 08:00–09:00 (NY pre-market 10–11am)
      • 13:00–14:00 (NY afternoon 2–3pm)

    Within these windows only:
      1. Price must first make a displacement (impulse) move — taking out a
         previous swing high (for bullish) or swing low (for bearish).
         This is the LIQUIDITY RAID — smart money sweeps stops.
      2. After the raid, a FAIR VALUE GAP (FVG) must form on the M1/M5 chart
         in the direction of the expected reversal.
         - Bullish FVG: candle[i-1] high < candle[i+1] low (gap left on way up)
         - The FVG is the imbalance where price wants to return
      3. Price retraces INTO the FVG — this is your entry zone.
      4. LTF confirmation (M1/M5 engulf, pin bar, or displacement) within the FVG.
      5. SL: below/above the FVG (or below the liquidity raid candle low/high)
      6. TP: previous session high/low or 2× risk minimum

    Why it works: Institutions run stops during these specific windows,
    create imbalance (FVG), then drive price back to fill the imbalance
    before continuing. The FVG is where they re-enter after the sweep.
    """
    name = "Silver Bullet"

    def scan(self, symbol: str, ms: MarketStructure,
             candles: dict) -> Optional[TradeSignal]:

        # Step 1: Must be in a Silver Bullet time window
        if not is_in_silver_bullet_window():
            return None

        m5  = candles.get("M5", pd.DataFrame())
        m1  = candles.get("M1", pd.DataFrame())
        h1  = candles.get("H1", pd.DataFrame())

        if len(m5) < 20 or len(m1) < 20:
            return None

        # Step 2: HTF bias must NOT be ranging
        if ms.htf_trend == "ranging" and ms.mtf_trend == "ranging":
            return None

        # Step 3: Detect liquidity raid + FVG on M1
        fvg, direction = self._find_sb_fvg(m1, m5, ms)
        if fvg is None:
            return None

        # Step 4: Price must currently be inside or touching the FVG
        current = self.mt5.get_current_price(symbol)
        mid     = (current.get('bid', 0) + current.get('ask', 0)) / 2

        if direction == "BUY" and not (fvg.bottom <= mid <= fvg.top * 1.002):
            return None
        if direction == "SELL" and not (fvg.bottom * 0.998 <= mid <= fvg.top):
            return None

        # Step 5: LTF confirmation inside the FVG
        ltf_conf = self.ltf.confirm_entry(
            symbol, direction, fvg.top, fvg.bottom, m5, m1
        )
        if not ltf_conf.confirmed:
            return None

        # Step 6: Confidence scoring
        score = 70  # base for being inside a SB window
        if ms.htf_trend == direction.lower() if direction == "BUY" else "bearish":
            score += 10
        if ms.mtf_trend == direction.lower() if direction == "BUY" else "bearish":
            score += 5
        if fvg.size_pips >= 5:
            score += 5
        score += min(10, ltf_conf.confidence // 10)

        # Build detailed reason
        now_utc  = datetime.now(tz=timezone.utc)
        now_ist  = now_utc.hour + 5 + (1 if now_utc.minute >= 30 else 0)
        session_name = _sb_window_name(now_utc.hour)

        confluence = [
            f"Inside Silver Bullet window: {session_name}",
            f"FVG detected: {fvg.bottom:.5f}–{fvg.top:.5f} ({fvg.size_pips:.1f} pips imbalance)",
            f"Liquidity raid preceded the FVG formation",
            f"HTF trend: {ms.htf_trend.upper()} | MTF trend: {ms.mtf_trend.upper()}",
            f"LTF: {ltf_conf.pattern} — {ltf_conf.ltf_reason}",
            f"Entry inside FVG midpoint at {fvg.mid:.5f}",
        ]

        detailed = (
            f"SILVER BULLET — {direction} {symbol}\n\n"
            f"Time: {now_utc.strftime('%H:%M')} UTC ({session_name})\n\n"
            f"What happened: During the {session_name} Silver Bullet window, "
            f"smart money executed a classic liquidity sweep — price {'spiked below' if direction == 'BUY' else 'spiked above'} "
            f"a previous swing {'low' if direction == 'BUY' else 'high'}, triggering stop-loss orders "
            f"from retail traders. Immediately after, a Fair Value Gap (FVG) formed at "
            f"{fvg.bottom:.5f}–{fvg.top:.5f} as institutions entered in the opposite direction. "
            f"This {fvg.size_pips:.1f}-pip imbalance represents the gap left behind by the "
            f"institutional entry candle — price is now retracing to fill it.\n\n"
            f"HTF context: The H4 trend is {ms.htf_trend.upper()}, aligning with the expected "
            f"move. H1 structure is {ms.mtf_trend.upper()}. {'This is a high-probability setup as all timeframes align.' if ms.htf_trend == ms.mtf_trend else 'Note: partial timeframe alignment.'}\n\n"
            f"LTF trigger: {ltf_conf.ltf_reason}\n\n"
            f"Trade levels:\n"
            f"  Entry: {ltf_conf.entry_price:.5f} (FVG fill entry)\n"
            f"  SL:    {ltf_conf.sl_price:.5f} (below/above FVG + 0.5 ATR buffer = {ltf_conf.sl_pips:.1f} pips)\n"
            f"  TP:    {ltf_conf.tp_price:.5f} ({ltf_conf.tp_pips:.1f} pips — {ltf_conf.rr_ratio:.1f}:1 RR)"
        )

        return TradeSignal(
            symbol=symbol, strategy_name=self.name,
            direction=direction,
            entry_price=ltf_conf.entry_price,
            sl_price=ltf_conf.sl_price, tp_price=ltf_conf.tp_price,
            sl_pips=ltf_conf.sl_pips, tp_pips=ltf_conf.tp_pips,
            rr_ratio=ltf_conf.rr_ratio, confidence_score=min(100, score),
            confluence_points=confluence, detailed_reason=detailed,
            ltf_pattern=ltf_conf.pattern, session=ms.current_session,
            htf_trend=ms.htf_trend,
        )

    def _find_sb_fvg(self, m1, m5, ms):
        """
        Searches M1 for a FVG that was preceded by a liquidity sweep.
        Returns (FVG, direction) or (None, None).
        """
        fvgs = ms.fvgs
        if not fvgs:
            return None, None

        # Prefer FVGs that align with the HTF bias
        for fvg in fvgs:
            if ms.htf_trend == "bullish" and fvg.direction == "bullish" and fvg.candles_ago <= 10:
                return fvg, "BUY"
            if ms.htf_trend == "bearish" and fvg.direction == "bearish" and fvg.candles_ago <= 10:
                return fvg, "SELL"

        # If HTF ranging, take freshest FVG
        if fvgs:
            fvg = min(fvgs, key=lambda x: x.candles_ago)
            direction = "BUY" if fvg.direction == "bullish" else "SELL"
            return fvg, direction
        return None, None


# ══════════════════════════════════════════════════════════
# STRATEGY 2 — SESSION TRADING
# ══════════════════════════════════════════════════════════

class SessionTradingStrategy(BaseStrategy):
    """
    Trades the London Open and New York Open kill zones.

    SETUP RULES:
    ─────────────
    1. Wait for the kill zone to open (London: 07:00–09:00 UTC,
       NY: 12:00–15:00 UTC).
    2. The ASIAN RANGE defines the consolidation from the prior session
       (00:00–07:00 UTC): note its high and low.
    3. At session open, wait for a RAID of the Asian range — price takes
       out the Asian high or low, then REVERSES back inside.
       This is the "stop hunt" before the real directional move.
    4. After the sweep, look for a DISPLACEMENT candle on H1/M15 in the
       true direction.
    5. On M15 or M5, find an Order Block or FVG left by the displacement.
    6. Enter on the retest of that OB/FVG.
    7. SL: above the session raid point. TP: opposite session range extreme.

    Why it works: London opens with fresh volume. Institutions need
    to fill massive orders. They first take out the most obvious stops
    (Asian range highs/lows) to get the liquidity they need, then drive
    price in the actual intended direction.
    """
    name = "Session Trading"

    def scan(self, symbol: str, ms: MarketStructure,
             candles: dict) -> Optional[TradeSignal]:

        session = get_current_session()
        if session not in ("london_open", "ny_open"):
            return None

        h1  = candles.get("H1",  pd.DataFrame())
        m15 = candles.get("M15", pd.DataFrame())
        m5  = candles.get("M5",  pd.DataFrame())
        m1  = candles.get("M1",  pd.DataFrame())

        if len(h1) < 30 or len(m15) < 20:
            return None

        # Asian range
        asian_high, asian_low = self._get_asian_range(h1)
        if asian_high == 0 or asian_low == 0:
            return None

        asian_range_pips = self._to_pips(asian_high - asian_low, symbol)
        if asian_range_pips < 10:  # too narrow to be meaningful
            return None

        # Detect the sweep
        direction, sweep_price = self._detect_session_sweep(h1, asian_high, asian_low)
        if direction is None:
            return None

        # Find OB or FVG after the sweep
        ob = self._find_post_sweep_ob(ms.order_blocks, direction)
        fvg = self._find_post_sweep_fvg(ms.fvgs, direction)

        if ob is None and fvg is None:
            return None

        zone_high = ob.high if ob else fvg.top
        zone_low  = ob.low  if ob else fvg.bottom

        # LTF confirmation
        ltf_conf = self.ltf.confirm_entry(symbol, direction, zone_high, zone_low, m5, m1)
        if not ltf_conf.confirmed:
            return None

        score = 65
        if ms.htf_trend.lower() == ("bullish" if direction == "BUY" else "bearish"):
            score += 15
        if ob and fvg:  # both present is extra confluent
            score += 10
        score += min(10, ltf_conf.confidence // 10)

        level_name = "Order Block" if ob else "Fair Value Gap"
        level_zone = f"{zone_low:.5f}–{zone_high:.5f}"

        confluence = [
            f"Session: {session.replace('_', ' ').title()} kill zone active",
            f"Asian range: {asian_low:.5f}–{asian_high:.5f} ({asian_range_pips:.0f} pips)",
            f"Sweep detected: {'Buyside' if direction == 'SELL' else 'Sellside'} liquidity taken at {sweep_price:.5f}",
            f"Post-sweep {level_name} at {level_zone}",
            f"HTF trend: {ms.htf_trend.upper()} confirming direction",
            f"LTF: {ltf_conf.pattern} — {ltf_conf.ltf_reason}",
        ]

        detailed = (
            f"SESSION TRADING — {direction} {symbol}\n\n"
            f"Session: {session.replace('_', ' ').title()} Kill Zone\n\n"
            f"What happened: The Asian session created a consolidation range between "
            f"{asian_low:.5f} and {asian_high:.5f} ({asian_range_pips:.0f} pips). "
            f"At the {'London' if 'london' in session else 'New York'} open, institutions "
            f"ran {'buyside' if direction == 'SELL' else 'sellside'} liquidity — spiking "
            f"{'above' if direction == 'SELL' else 'below'} the Asian range {'high' if direction == 'SELL' else 'low'} "
            f"at {sweep_price:.5f} to absorb stop orders. After filling the liquidity, "
            f"price reversed and left a {level_name} at {level_zone}.\n\n"
            f"HTF context: H4 is {ms.htf_trend.upper()}, {('confirming' if ms.htf_trend.lower() == ('bullish' if direction=='BUY' else 'bearish') else 'partially against')} this trade direction. "
            f"H1 structure: {ms.mtf_trend.upper()}.\n\n"
            f"Entry logic: Waiting for price to retrace into the {level_name} at {level_zone} "
            f"where institutional orders likely remain. LTF confirmation: {ltf_conf.ltf_reason}\n\n"
            f"Trade levels:\n"
            f"  Entry: {ltf_conf.entry_price:.5f}\n"
            f"  SL:    {ltf_conf.sl_price:.5f} ({ltf_conf.sl_pips:.1f} pips — beyond the sweep point)\n"
            f"  TP:    {ltf_conf.tp_price:.5f} ({ltf_conf.tp_pips:.1f} pips — {ltf_conf.rr_ratio:.1f}:1 RR)"
        )

        return TradeSignal(
            symbol=symbol, strategy_name=self.name,
            direction=direction,
            entry_price=ltf_conf.entry_price,
            sl_price=ltf_conf.sl_price, tp_price=ltf_conf.tp_price,
            sl_pips=ltf_conf.sl_pips, tp_pips=ltf_conf.tp_pips,
            rr_ratio=ltf_conf.rr_ratio, confidence_score=min(100, score),
            confluence_points=confluence, detailed_reason=detailed,
            ltf_pattern=ltf_conf.pattern, session=session,
            htf_trend=ms.htf_trend,
        )

    def _get_asian_range(self, h1):
        from datetime import datetime, timezone
        now = datetime.now(tz=timezone.utc)
        today_asian = h1[
            (h1.index.date == now.date()) &
            (h1.index.hour >= 0) & (h1.index.hour < 7)
        ]
        if len(today_asian) < 3:
            yesterday = h1.tail(24)
            return yesterday['high'].max(), yesterday['low'].min()
        return today_asian['high'].max(), today_asian['low'].min()

    def _detect_session_sweep(self, h1, asian_high, asian_low):
        recent = h1.tail(6)
        for _, candle in recent.iterrows():
            if candle['high'] > asian_high * 1.0003 and candle['close'] < asian_high:
                return "BUY", candle['high']    # swept buyside, now going down
            if candle['low'] < asian_low * 0.9997 and candle['close'] > asian_low:
                return "SELL", candle['low']    # swept sellside, now going up
        return None, None

    def _find_post_sweep_ob(self, obs, direction):
        aligned = [ob for ob in obs
                   if ob.direction == ("bullish" if direction == "BUY" else "bearish")
                   and ob.candles_ago <= 15]
        return aligned[0] if aligned else None

    def _find_post_sweep_fvg(self, fvgs, direction):
        aligned = [f for f in fvgs
                   if f.direction == ("bullish" if direction == "BUY" else "bearish")
                   and f.candles_ago <= 15]
        return aligned[0] if aligned else None


# ══════════════════════════════════════════════════════════
# STRATEGY 3 — SMC / ORDER BLOCK
# ══════════════════════════════════════════════════════════

class SMCOrderBlockStrategy(BaseStrategy):
    """
    Pure Smart Money Concepts Order Block strategy.

    SETUP RULES:
    ─────────────
    1. H4 trend must be established (bullish or bearish).
    2. On H1, find the most recent unmitigated Order Block in the
       direction of the H4 trend:
       - Bullish OB: last bearish candle before a strong bullish impulse
       - Bearish OB: last bullish candle before a strong bearish impulse
    3. The impulse candle must be ≥ 1.5× ATR (confirming institutional activity).
    4. Price must retrace INTO the OB zone (50% of the OB candle body).
    5. On M15, look for a BOS (Break of Structure) confirming the OB is holding.
    6. On M5/M1, get entry confirmation (engulf / pin / displacement).
    7. SL: 3-5 pips below the OB low (for bullish OB) or above OB high (for bearish OB).
    8. TP: next HTF liquidity level or 2× risk minimum.

    Scoring bonuses:
    - OB aligns with a FVG at the same level (+15)
    - OB aligns with a Fibonacci 0.618–0.786 retracement (+10)
    - OB was previously tested and held (+10)
    - OB formed after a BOS, not just any impulse (+10)
    """
    name = "SMC Order Block"

    def scan(self, symbol: str, ms: MarketStructure,
             candles: dict) -> Optional[TradeSignal]:

        if ms.htf_trend == "ranging":
            return None

        direction = "BUY" if ms.htf_trend == "bullish" else "SELL"

        h1  = candles.get("H1",  pd.DataFrame())
        m15 = candles.get("M15", pd.DataFrame())
        m5  = candles.get("M5",  pd.DataFrame())
        m1  = candles.get("M1",  pd.DataFrame())

        # Find the best aligned OB
        target_obs = [ob for ob in ms.order_blocks
                      if ob.direction == ("bullish" if direction == "BUY" else "bearish")
                      and not ob.mitigated]
        if not target_obs:
            return None

        ob = max(target_obs, key=lambda x: x.strength)

        # Price must be at or near the OB
        current = self.mt5.get_current_price(symbol)
        mid = (current.get('bid', 0) + current.get('ask', 0)) / 2

        if direction == "BUY":
            if not (ob.low * 0.9995 <= mid <= ob.high * 1.002):
                return None
        else:
            if not (ob.low * 0.998 <= mid <= ob.high * 1.0005):
                return None

        # M15 BOS confirmation (price should have shown a mini-BOS before touching OB)
        m15_bos = self._check_m15_bos(m15, direction)

        # LTF confirmation
        ltf_conf = self.ltf.confirm_entry(symbol, direction, ob.high, ob.low, m5, m1)
        if not ltf_conf.confirmed:
            return None

        # Confluence scoring
        score = 60
        score += min(20, int(ob.strength / 5))
        if m15_bos:
            score += 10
        if ms.mtf_trend.lower() == ("bullish" if direction == "BUY" else "bearish"):
            score += 10
        score += min(10, ltf_conf.confidence // 10)

        # FVG + OB convergence check
        fvg_at_ob = self._fvg_at_ob_level(ms.fvgs, ob, direction)
        if fvg_at_ob:
            score += 15

        # Fibonacci alignment
        fib_aligned, fib_level = self._check_fib_alignment(ob, candles.get("H4"), direction)
        if fib_aligned:
            score += 10

        confluence = [
            f"H4 trend: {ms.htf_trend.upper()} — strong directional bias established",
            f"{'Bullish' if direction == 'BUY' else 'Bearish'} Order Block at {ob.low:.5f}–{ob.high:.5f}",
            f"OB impulse strength: {ob.impulse_size_atr:.1f}× ATR — institutional-grade move",
            f"OB is {'unmitigated' if not ob.mitigated else 'partially mitigated'}, formed {ob.candles_ago} candles ago",
        ]
        if m15_bos:
            confluence.append(f"M15 Break of Structure confirmed in {direction} direction")
        if fvg_at_ob:
            confluence.append(f"FVG overlapping the OB zone — double confluence at same level")
        if fib_aligned:
            confluence.append(f"Fibonacci {fib_level} retracement aligning with OB")
        confluence.append(f"LTF: {ltf_conf.pattern} — {ltf_conf.ltf_reason}")

        detailed = (
            f"SMC ORDER BLOCK — {direction} {symbol}\n\n"
            f"What happened: On H4, the trend is clearly {ms.htf_trend.upper()} — price is making "
            f"{'higher highs and higher lows' if ms.htf_trend == 'bullish' else 'lower highs and lower lows'}. "
            f"On H1, a {'bearish' if direction == 'BUY' else 'bullish'} candle at {ob.low:.5f}–{ob.high:.5f} "
            f"was followed by a {ob.impulse_size_atr:.1f}× ATR impulse — this is the Order Block where "
            f"institutional orders were placed. Price has now retraced into this zone.\n\n"
            f"Why this level matters: The OB represents where large institutions {'bought' if direction == 'BUY' else 'sold'} "
            f"aggressively — they are likely to {'defend' if direction == 'BUY' else 'short'} this level again. "
            f"{'An overlapping FVG adds extra magnetism to this zone.' if fvg_at_ob else ''} "
            f"{'The Fibonacci ' + str(fib_level) + ' retracement coincides with this OB — a classic OTE (Optimal Trade Entry).' if fib_aligned else ''}\n\n"
            f"M15 structure: {'Break of Structure confirmed — price showed a mini-BOS on M15, meaning smart money is already active at this level.' if m15_bos else 'Watching for M15 BOS confirmation.'}\n\n"
            f"LTF entry trigger: {ltf_conf.ltf_reason}\n\n"
            f"Trade levels:\n"
            f"  Entry: {ltf_conf.entry_price:.5f} (inside OB, after LTF confirmation)\n"
            f"  SL:    {ltf_conf.sl_price:.5f} ({ltf_conf.sl_pips:.1f} pips — below/above OB with ATR buffer)\n"
            f"  TP:    {ltf_conf.tp_price:.5f} ({ltf_conf.tp_pips:.1f} pips — {ltf_conf.rr_ratio:.1f}:1 RR)"
        )

        return TradeSignal(
            symbol=symbol, strategy_name=self.name,
            direction=direction,
            entry_price=ltf_conf.entry_price,
            sl_price=ltf_conf.sl_price, tp_price=ltf_conf.tp_price,
            sl_pips=ltf_conf.sl_pips, tp_pips=ltf_conf.tp_pips,
            rr_ratio=ltf_conf.rr_ratio, confidence_score=min(100, score),
            confluence_points=confluence, detailed_reason=detailed,
            ltf_pattern=ltf_conf.pattern, session=ms.current_session,
            htf_trend=ms.htf_trend,
        )

    def _check_m15_bos(self, m15, direction):
        if len(m15) < 10:
            return False
        closes = m15['close'].values[-10:]
        highs  = m15['high'].values[-10:]
        lows   = m15['low'].values[-10:]
        if direction == "BUY":
            return closes[-1] > max(highs[-5:-1])
        return closes[-1] < min(lows[-5:-1])

    def _fvg_at_ob_level(self, fvgs, ob, direction):
        for fvg in fvgs:
            if fvg.direction == ("bullish" if direction == "BUY" else "bearish"):
                if fvg.bottom <= ob.high and fvg.top >= ob.low:
                    return True
        return False

    def _check_fib_alignment(self, ob, h4, direction):
        if h4 is None or len(h4) < 30:
            return False, ""
        swing_high = h4['high'].values[-30:].max()
        swing_low  = h4['low'].values[-30:].min()
        fibs = get_fib_levels(swing_high, swing_low)
        for level, price in fibs.items():
            if float(level) in [0.618, 0.705, 0.786]:
                if ob.low <= price <= ob.high:
                    return True, level
        return False, ""


# ══════════════════════════════════════════════════════════
# STRATEGY 4 — TURTLE SOUP (False Breakout Reversal)
# ══════════════════════════════════════════════════════════

class TurtleSoupStrategy(BaseStrategy):
    """
    Turtle Soup is a false breakout reversal — named after the Turtle Traders
    strategy which it exploits by fading their breakout entries.

    SETUP RULES:
    ─────────────
    1. Identify a clean 20-bar swing high or swing low (a clear, obvious level
       that retail breakout traders will be watching).
    2. Wait for price to BREAK ABOVE the swing high (or BELOW the swing low)
       by at least 2 pips — triggering the breakout traders and their stops.
    3. The breakout candle must CLOSE BACK INSIDE the range within
       TURTLE_MAX_SWEEP_CANDLES candles — confirming it was a false breakout.
    4. A REJECTION candle (pin bar, engulf) must form immediately after closing back.
    5. LTF confirmation (M5/M1) in the reversal direction.
    6. SL: above the false breakout wick high (for bearish reversal) or
       below the wick low (for bullish reversal) + 2 pip buffer.
    7. TP: the OPPOSITE side's swing (minimum 2× risk).

    Why it works: Large institutions deliberately run stops beyond obvious swing
    levels, absorbing the breakout traders' orders. Once they've accumulated enough,
    they reverse price sharply. Retail traders get trapped in the breakout;
    you fade them by going with the institutions.
    """
    name = "Turtle Soup"

    def scan(self, symbol: str, ms: MarketStructure,
             candles: dict) -> Optional[TradeSignal]:

        h1  = candles.get("H1",  pd.DataFrame())
        m15 = candles.get("M15", pd.DataFrame())
        m5  = candles.get("M5",  pd.DataFrame())
        m1  = candles.get("M1",  pd.DataFrame())

        if len(h1) < 30 or len(m15) < 20:
            return None

        pip_size = self._pip_size(symbol)

        # Find the swing high/low
        swing_high = max(h1['high'].values[-TURTLE_LOOKBACK_BARS:])
        swing_low  = min(h1['low'].values[-TURTLE_LOOKBACK_BARS:])

        recent_candles = h1.tail(TURTLE_MAX_SWEEP_CANDLES + 2)

        direction, sweep_price, swing_ref = self._detect_false_breakout(
            recent_candles, swing_high, swing_low, pip_size
        )
        if direction is None:
            return None

        # LTF confirmation in reversal direction
        if direction == "BUY":
            zone_high = sweep_price * 1.0002
            zone_low  = sweep_price - 10 * pip_size
        else:
            zone_high = sweep_price + 10 * pip_size
            zone_low  = sweep_price * 0.9998

        ltf_conf = self.ltf.confirm_entry(symbol, direction, zone_high, zone_low, m5, m1)
        if not ltf_conf.confirmed:
            return None

        score = 65
        if ms.htf_trend.lower() == ("bullish" if direction == "BUY" else "bearish"):
            score += 15
        score += min(10, ltf_conf.confidence // 10)

        sweep_pips = self._to_pips(abs(sweep_price - swing_ref), symbol)
        confluence = [
            f"20-bar swing {'high' if direction == 'BUY' else 'low'} identified at {swing_ref:.5f}",
            f"False breakout: price swept {sweep_pips:.1f} pips beyond the swing level",
            f"Candle closed BACK inside the range — confirming the trap",
            f"HTF trend: {ms.htf_trend.upper()}",
            f"LTF reversal: {ltf_conf.pattern} — {ltf_conf.ltf_reason}",
        ]

        detailed = (
            f"TURTLE SOUP — {direction} {symbol}\n\n"
            f"What happened: A clear 20-bar swing {'high' if direction == 'BUY' else 'low'} "
            f"at {swing_ref:.5f} attracted breakout traders (and their stops). Price briefly "
            f"{'broke above' if direction == 'BUY' else 'broke below'} this level by {sweep_pips:.1f} pips "
            f"to {sweep_price:.5f}, triggering breakout entries and stop orders. However, "
            f"the candle closed {'below' if direction == 'BUY' else 'above'} the swing level — "
            f"a definitive rejection of the breakout. This is the classic Turtle Soup pattern: "
            f"institutions consumed the stop-order liquidity at the obvious level and reversed.\n\n"
            f"HTF context: H4 is {ms.htf_trend.upper()}. "
            f"{'This reversal aligns with the HTF trend — high probability.' if ms.htf_trend.lower() == ('bullish' if direction == 'BUY' else 'bearish') else 'Note: counter-trend move — manage risk carefully.'}\n\n"
            f"LTF: {ltf_conf.ltf_reason}\n\n"
            f"Trade levels:\n"
            f"  Entry: {ltf_conf.entry_price:.5f}\n"
            f"  SL:    {ltf_conf.sl_price:.5f} ({ltf_conf.sl_pips:.1f} pips — just beyond the sweep wick)\n"
            f"  TP:    {ltf_conf.tp_price:.5f} ({ltf_conf.tp_pips:.1f} pips — {ltf_conf.rr_ratio:.1f}:1 RR)"
        )

        return TradeSignal(
            symbol=symbol, strategy_name=self.name,
            direction=direction,
            entry_price=ltf_conf.entry_price,
            sl_price=ltf_conf.sl_price, tp_price=ltf_conf.tp_price,
            sl_pips=ltf_conf.sl_pips, tp_pips=ltf_conf.tp_pips,
            rr_ratio=ltf_conf.rr_ratio, confidence_score=min(100, score),
            confluence_points=confluence, detailed_reason=detailed,
            ltf_pattern=ltf_conf.pattern, session=ms.current_session,
            htf_trend=ms.htf_trend,
        )

    def _detect_false_breakout(self, candles, swing_high, swing_low, pip_size):
        for i, (idx, row) in enumerate(candles.iterrows()):
            # Bearish turtle soup: swept high, closed back below
            buffer = TURTLE_BUFFER_PIPS * pip_size
            if (row['high'] > swing_high + buffer and
                    row['close'] < swing_high):
                return "SELL", row['high'], swing_high

            # Bullish turtle soup: swept low, closed back above
            if (row['low'] < swing_low - buffer and
                    row['close'] > swing_low):
                return "BUY", row['low'], swing_low
        return None, None, None


# ══════════════════════════════════════════════════════════
# STRATEGY 5 — KISS OF DEATH
# ══════════════════════════════════════════════════════════

class KissOfDeathStrategy(BaseStrategy):
    """
    The Kiss of Death is a three-phase confirmation entry:
    Phase 1 — BOS (Break of Structure):
      Price makes a significant break of a key H1 swing level,
      confirming a structural shift.
    Phase 2 — Retracement to OB:
      After the BOS, price retraces to the Order Block that was
      left behind by the impulse that caused the BOS.
      This is the 'kiss' — price returns to touch the OB one last time.
    Phase 3 — Rejection (Death):
      A clear rejection candle forms at the OB — pin bar, engulf,
      or displacement — before price continues in the BOS direction.
      This rejection is the 'death' of the retracement.

    Why it works: The BOS tells you the direction. The OB is where
    institutions placed their orders and where they will defend the
    level again. The rejection candle is the real-time proof that
    they are indeed defending it. Three confirmations before entry.

    SL: just beyond the OB (invalidates the setup if breached)
    TP: the next major liquidity level (swing high/low or equal highs/lows)
    """
    name = "Kiss of Death"

    def scan(self, symbol: str, ms: MarketStructure,
             candles: dict) -> Optional[TradeSignal]:

        if ms.last_bos is None:
            return None

        direction = "BUY" if ms.last_bos == "bullish" else "SELL"

        h1  = candles.get("H1",  pd.DataFrame())
        m15 = candles.get("M15", pd.DataFrame())
        m5  = candles.get("M5",  pd.DataFrame())
        m1  = candles.get("M1",  pd.DataFrame())

        if len(h1) < 20:
            return None

        # Find the OB that caused the BOS
        target_obs = [ob for ob in ms.order_blocks
                      if ob.direction == ("bullish" if direction == "BUY" else "bearish")
                      and not ob.mitigated
                      and ob.candles_ago <= 20]
        if not target_obs:
            return None

        ob = max(target_obs, key=lambda x: x.impulse_size_atr)

        # Price must be retesting the OB now
        current = self.mt5.get_current_price(symbol)
        mid = (current.get('bid', 0) + current.get('ask', 0)) / 2

        if direction == "BUY":
            if not (ob.body_low * 0.9998 <= mid <= ob.high * 1.001):
                return None
        else:
            if not (ob.low * 0.999 <= mid <= ob.body_high * 1.0002):
                return None

        # The "kiss" is confirmed — now need the "death" (rejection)
        ltf_conf = self.ltf.confirm_entry(symbol, direction, ob.high, ob.low, m5, m1)
        if not ltf_conf.confirmed:
            return None

        # Only take if rejection is a pin bar or engulf (not just displacement)
        if ltf_conf.pattern not in ("Bullish engulfing", "Bearish engulfing",
                                     "Bullish pin bar", "Bearish pin bar",
                                     "Inside bar breakout"):
            return None

        score = 70
        if ms.htf_trend.lower() == ("bullish" if direction == "BUY" else "bearish"):
            score += 15
        if ms.mtf_trend.lower() == ("bullish" if direction == "BUY" else "bearish"):
            score += 5
        score += min(10, ltf_conf.confidence // 10)

        # Next liquidity target
        liq = self._find_target_liquidity(ms.liquidity_levels, direction, mid)

        confluence = [
            f"H1 Break of Structure: {'bullish' if direction == 'BUY' else 'bearish'} BOS confirmed",
            f"{'Bullish' if direction == 'BUY' else 'Bearish'} OB at {ob.low:.5f}–{ob.high:.5f} (impulse: {ob.impulse_size_atr:.1f}× ATR)",
            f"Phase 2 complete — price returned to 'kiss' the OB",
            f"Phase 3 (death): {ltf_conf.pattern} rejection at OB confirmed",
            f"HTF: {ms.htf_trend.upper()} | MTF: {ms.mtf_trend.upper()}",
            f"LTF: {ltf_conf.ltf_reason}",
        ]
        if liq:
            confluence.append(f"Target liquidity: {liq:.5f}")

        detailed = (
            f"KISS OF DEATH — {direction} {symbol}\n\n"
            f"Three-phase confirmation setup:\n\n"
            f"Phase 1 — Break of Structure (BOS):\n"
            f"H1 confirmed a {'bullish' if direction == 'BUY' else 'bearish'} BOS — price broke "
            f"a key swing {'high' if direction == 'BUY' else 'low'}, signaling a structural shift. "
            f"HTF trend is {ms.htf_trend.upper()}, {'aligning' if ms.htf_trend.lower() == ('bullish' if direction == 'BUY' else 'bearish') else 'partially conflicting'} with this BOS.\n\n"
            f"Phase 2 — The Kiss:\n"
            f"After the BOS impulse, price retraced to the Order Block at {ob.low:.5f}–{ob.high:.5f}. "
            f"This OB was created when a {ob.impulse_size_atr:.1f}× ATR move launched the BOS. "
            f"Price has now returned to this level — where institutional orders are waiting. "
            f"This is the 'kiss' — one final touch of the key level before continuation.\n\n"
            f"Phase 3 — The Death:\n"
            f"A {ltf_conf.pattern} has formed at the OB — {ltf_conf.ltf_reason}. "
            f"This is the rejection confirmation (the 'death' of the retracement). "
            f"Price is expected to now continue {'higher' if direction == 'BUY' else 'lower'} "
            f"{'toward ' + str(round(liq, 5)) if liq else 'toward the next structural high/low'}.\n\n"
            f"Trade levels:\n"
            f"  Entry: {ltf_conf.entry_price:.5f}\n"
            f"  SL:    {ltf_conf.sl_price:.5f} ({ltf_conf.sl_pips:.1f} pips — beyond OB invalidation)\n"
            f"  TP:    {ltf_conf.tp_price:.5f} ({ltf_conf.tp_pips:.1f} pips — {ltf_conf.rr_ratio:.1f}:1 RR)"
        )

        return TradeSignal(
            symbol=symbol, strategy_name=self.name,
            direction=direction,
            entry_price=ltf_conf.entry_price,
            sl_price=ltf_conf.sl_price, tp_price=ltf_conf.tp_price,
            sl_pips=ltf_conf.sl_pips, tp_pips=ltf_conf.tp_pips,
            rr_ratio=ltf_conf.rr_ratio, confidence_score=min(100, score),
            confluence_points=confluence, detailed_reason=detailed,
            ltf_pattern=ltf_conf.pattern, session=ms.current_session,
            htf_trend=ms.htf_trend,
        )

    def _find_target_liquidity(self, levels, direction, current_price):
        """Find nearest liquidity level in the direction of trade."""
        if not levels:
            return None
        if direction == "BUY":
            above = [l.price for l in levels if l.price > current_price]
            return min(above) if above else None
        else:
            below = [l.price for l in levels if l.price < current_price]
            return max(below) if below else None


# ── Utilities ─────────────────────────────────────────────

def _sb_window_name(hour_utc: int) -> str:
    if 3 <= hour_utc < 4:
        return "London 10-11am (Silver Bullet)"
    if 8 <= hour_utc < 9:
        return "NY Pre-Market 10-11am (Silver Bullet)"
    if 13 <= hour_utc < 14:
        return "NY Afternoon 2-3pm (Silver Bullet)"
    return "Silver Bullet Window"
