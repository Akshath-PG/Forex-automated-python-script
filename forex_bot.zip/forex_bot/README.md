# FOREX TRADING BOT — COMPLETE SETUP GUIDE

## What this bot does
- Scans EURUSD, GBPUSD, USDJPY, USDCHF, XAUUSD, XAGUSD, US30, NAS100 every 60 seconds
- Detects setups using 5 strategies: Silver Bullet, Session Trading, SMC OB, Turtle Soup, Kiss of Death
- Sends detailed alerts to Telegram and WhatsApp with full trade reasoning
- Waits for your confirmation before placing any order in MT5
- Uses a LightGBM ML model trained on 4 years of data as a quality filter

---

## PROJECT STRUCTURE

```
forex_bot/
├── main.py                    ← START HERE (run this)
├── requirements.txt
├── config/
│   └── settings.py            ← ALL settings — edit this first
├── core/
│   ├── mt5_handler.py         ← MT5 connection, data, order placement
│   ├── market_structure.py    ← HTF trend, OBs, FVGs, liquidity
│   ├── ltf_confirmation.py    ← M5/M1 entry confirmation patterns
│   └── news_filter.py         ← ForexFactory news blocking
├── strategies/
│   └── all_strategies.py      ← All 5 strategy classes
├── ml/
│   └── model.py               ← Training pipeline + live scorer
├── notifications/
│   └── notifier.py            ← Telegram bot + WhatsApp (Twilio)
├── data/                      ← Training CSV, trade log
└── logs/                      ← Bot log file
```

---

## STEP 1 — INSTALL DEPENDENCIES

```bash
pip install MetaTrader5 pandas numpy lightgbm scikit-learn python-telegram-bot twilio
```

**Windows only** (MT5 only works on Windows natively):
- If you are on Mac/Linux, use a Windows VPS or run MT5 in Wine

---

## STEP 2 — CONFIGURE settings.py

Open `config/settings.py` and fill in:

```python
MT5_LOGIN      = 12345678          # your MT5 account number
MT5_PASSWORD   = "your_password"
MT5_SERVER     = "ICMarkets-Live"  # your broker's server name
```

**How to find your server name:**
Open MT5 → File → Login to Trade Account → you can see the server name there.

---

## STEP 3 — CREATE TELEGRAM BOT

1. Open Telegram → search for `@BotFather`
2. Send `/newbot` → follow prompts → copy the token
3. Paste into settings.py: `TELEGRAM_BOT_TOKEN = "123456:ABC..."`
4. Find your Chat ID: talk to `@userinfobot` on Telegram → copy your ID
5. Paste: `TELEGRAM_CHAT_ID = "123456789"`

---

## STEP 4 — WHATSAPP (TWILIO)

1. Create account at twilio.com
2. Go to Console → get Account SID and Auth Token
3. Enable WhatsApp Sandbox or buy a WhatsApp number
4. Paste into settings.py:
   ```python
   TWILIO_ACCOUNT_SID  = "ACxxxxxxxxx"
   TWILIO_AUTH_TOKEN   = "your_token"
   YOUR_WHATSAPP_NUMBER = "whatsapp:+91XXXXXXXXXX"
   ```

---

## STEP 5 — TRAIN THE ML MODEL

This downloads 4 years of data from your MT5 broker and trains the model.
**Only needs to be done once.** Takes ~30-60 minutes depending on data volume.

```bash
python main.py --train
```

What it does:
1. Downloads H4, H1, M15, M5 data for all symbols (4 years each)
2. Applies quality filters (removes zero-volume, gaps, outliers)
3. Replays the data bar-by-bar, detecting historical setups
4. Labels each setup: 1 = TP hit, 0 = SL hit
5. Trains LightGBM with TimeSeriesSplit cross-validation (no data leakage)
6. Saves model to `ml/trained_model.pkl`

Expected output:
```
Mean CV AUC: 0.6X ± 0.02
Top features: trend_aligned, ob_impulse_atr, is_london_open...
Model saved to ml/trained_model.pkl
```
AUC of 0.60-0.65 is realistic and expected for forex. Do not trust models claiming >0.75 AUC — they are overfit.

---

## STEP 6 — RUN THE BOT

```bash
python main.py
```

The bot will:
- Connect to MT5
- Start Telegram polling
- Scan every 60 seconds

---

## HOW A SIGNAL LOOKS ON TELEGRAM

```
⚡ 🟢 SILVER BULLET SIGNAL
━━━━━━━━━━━━━━━━━━━━━━━━━━━
BUY XAUUSD
📅 15 Jan 2025, 03:42 PM IST

📊 TRADE LEVELS
  Entry:       2318.500
  Stop Loss:   2311.200  (−7.3 pips)
  Take Profit:  2332.000  (+13.5 pips)
  R:R Ratio:   1:1.85
  Lot Size:    0.05 lots
  Risk:        $50.00 (1% of balance)

🧠 SIGNAL QUALITY
[████████░░] GOOD
Score: 74/100  |  Session: Ny Open

✅ CONFLUENCE FACTORS
  ✅ Inside Silver Bullet window: NY Pre-Market 10-11am
  ✅ FVG detected: 2317.80–2318.90 (5.5 pips imbalance)
  ✅ Liquidity raid preceded the FVG formation
  ✅ HTF trend: BULLISH | MTF trend: BULLISH
  ✅ LTF: Bullish pin bar...

[✅ BUY 0.05 lots]  [❌ SKIP]
```

Tap `✅ BUY` → order placed instantly in MT5.

---

## STRATEGY QUICK REFERENCE

### Silver Bullet (ICT)
- **When:** 3-4am UTC, 8-9am UTC, 1-2pm UTC ONLY
- **What:** FVG entry after a liquidity raid
- **SL:** Below/above the FVG

### Session Trading
- **When:** London Open (7-9am UTC) or NY Open (12-3pm UTC)
- **What:** Asian range sweep → post-sweep OB/FVG entry
- **SL:** Beyond the sweep wick

### SMC Order Block
- **When:** Any time, but prefers kill zones
- **What:** HTF OB retest with M15 BOS confirmation
- **SL:** Below/above the OB + buffer

### Turtle Soup
- **When:** Any time
- **What:** False breakout beyond 20-bar swing → reversal
- **SL:** Just beyond the false breakout wick

### Kiss of Death
- **When:** After a BOS has occurred on H1
- **What:** BOS → retrace to OB → rejection candle
- **SL:** Beyond the OB (if breached, setup invalidated)

---

## RISK SETTINGS (edit in settings.py)

```python
RISK_PERCENT_PER_TRADE = 1.0    # 1% per trade
MIN_RR_RATIO           = 2.0    # minimum 1:2 RR
MAX_CONCURRENT_TRADES  = 3      # never more than 3 open
MAX_SPREAD_PIPS        = 3.0    # skip if spread too wide
MIN_CONFLUENCE_SCORE   = 60     # 0-100 quality threshold
```

---

## PAPER TRADING FIRST

Before going live, change your MT5 login to a demo account in settings.py.
Run for 2-4 weeks. Review `data/trade_log.csv` to assess performance.
Only switch to live after you're satisfied with the results.

---

## TROUBLESHOOTING

**MT5 won't connect:**
- Make sure MT5 is open and logged in on the same machine
- Check that Algo Trading is enabled in MT5 settings

**No signals after hours of running:**
- The bot only alerts during active sessions. Most signals occur 7-9am and 12-3pm UTC (12:30-2:30pm and 5:30-8:30pm IST)
- Check bot.log for "skipped" messages to understand what's happening

**Telegram bot not responding:**
- Make sure the bot token is correct
- Start a conversation with your bot first before running
