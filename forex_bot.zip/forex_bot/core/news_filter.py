"""
=============================================================
  CORE — NEWS FILTER
  Blocks trades during high-impact news events.
  Sources: ForexFactory RSS feed + fallback hardcoded list.

  Logic:
    - Parse ForexFactory RSS for today's events
    - Filter for HIGH impact events only
    - For symbols with USD, EUR, GBP, JPY, XAU exposure,
      check if current time is within the block window
    - Return True (blocked) or False (clear to trade)
=============================================================
"""

import logging
import xml.etree.ElementTree as ET
from datetime import datetime, timezone, timedelta
from typing import List
import os, sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.settings import *

logger = logging.getLogger(__name__)


class NewsFilter:
    """
    Fetches and caches today's high-impact news events.
    Refreshes the cache every 30 minutes.
    """

    def __init__(self):
        self._events = []
        self._last_fetch = None
        self.REFRESH_INTERVAL = 1800  # 30 minutes

    def is_blocked(self, symbol: str) -> tuple:
        """
        Returns (blocked: bool, reason: str)
        blocked = True means no trades allowed right now.
        """
        self._refresh_if_needed()

        currencies = self._symbol_to_currencies(symbol)
        now_utc = datetime.now(tz=timezone.utc)

        for event in self._events:
            if event.get("impact") != "High":
                continue
            if event.get("currency") not in currencies:
                continue

            event_time = event.get("time")
            if event_time is None:
                continue

            window_start = event_time - timedelta(minutes=NEWS_BLOCK_MINUTES_BEFORE)
            window_end   = event_time + timedelta(minutes=NEWS_BLOCK_MINUTES_AFTER)

            if window_start <= now_utc <= window_end:
                mins_to = int((event_time - now_utc).total_seconds() / 60)
                if mins_to >= 0:
                    reason = (f"🚫 NEWS BLOCK: {event.get('title', 'High impact event')} "
                              f"({event.get('currency')}) in {mins_to} min")
                else:
                    reason = (f"🚫 NEWS BLOCK: {event.get('title', 'High impact event')} "
                              f"({event.get('currency')}) — {abs(mins_to)} min ago, "
                              f"waiting for volatility to settle")
                return True, reason

        return False, ""

    def next_events(self, symbol: str, count: int = 3) -> List[dict]:
        """Returns next N upcoming events for the symbol's currencies."""
        self._refresh_if_needed()
        currencies = self._symbol_to_currencies(symbol)
        now_utc = datetime.now(tz=timezone.utc)

        upcoming = [
            e for e in self._events
            if e.get("currency") in currencies
            and e.get("time") and e["time"] > now_utc
        ]
        upcoming.sort(key=lambda x: x["time"])
        return upcoming[:count]

    def _refresh_if_needed(self):
        import time
        now = time.time()
        if self._last_fetch and (now - self._last_fetch) < self.REFRESH_INTERVAL:
            return
        self._fetch_events()
        self._last_fetch = now

    def _fetch_events(self):
        """Fetches ForexFactory calendar RSS. Falls back to empty list on failure."""
        try:
            import urllib.request
            url = "https://www.forexfactory.com/ff_calendar_thisweek.xml"
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=10) as response:
                xml_data = response.read()
            self._parse_ff_xml(xml_data)
            logger.info(f"News feed refreshed: {len(self._events)} events loaded")
        except Exception as e:
            logger.warning(f"News fetch failed: {e} — using cached events")
            if not self._events:
                self._events = self._hardcoded_events()

    def _parse_ff_xml(self, xml_data: bytes):
        """Parses ForexFactory's XML calendar format."""
        events = []
        try:
            root = ET.fromstring(xml_data)
            for event in root.findall(".//event"):
                title    = self._get_text(event, "title")
                currency = self._get_text(event, "country")
                impact   = self._get_text(event, "impact")
                date_str = self._get_text(event, "date")
                time_str = self._get_text(event, "time")

                if impact not in ("High", "Medium"):
                    continue

                dt = self._parse_ff_datetime(date_str, time_str)
                events.append({
                    "title":    title,
                    "currency": currency.upper(),
                    "impact":   impact,
                    "time":     dt,
                })
        except Exception as e:
            logger.error(f"XML parse error: {e}")

        self._events = events

    @staticmethod
    def _get_text(element, tag):
        child = element.find(tag)
        return child.text.strip() if child is not None and child.text else ""

    @staticmethod
    def _parse_ff_datetime(date_str: str, time_str: str):
        """ForexFactory uses US Eastern time. Convert to UTC."""
        try:
            if not date_str:
                return None
            # FF format: "Jan 15 2025" + "8:30am"
            if time_str:
                dt_str = f"{date_str} {time_str}"
                formats = ["%b %d %Y %I:%M%p", "%b %d %Y %I%p"]
                for fmt in formats:
                    try:
                        dt_est = datetime.strptime(dt_str.strip(), fmt)
                        # EST = UTC-5 / EDT = UTC-4 (approximate with UTC-5)
                        dt_utc = dt_est.replace(tzinfo=timezone.utc) + timedelta(hours=5)
                        return dt_utc
                    except ValueError:
                        continue
            return None
        except Exception:
            return None

    @staticmethod
    def _symbol_to_currencies(symbol: str) -> list:
        """Maps a trading symbol to its constituent currencies."""
        currency_map = {
            "EURUSD": ["EUR", "USD"], "GBPUSD": ["GBP", "USD"],
            "USDJPY": ["USD", "JPY"], "USDCHF": ["USD", "CHF"],
            "XAUUSD": ["USD", "XAU"], "XAGUSD": ["USD", "XAG"],
            "US30.cash": ["USD"],     "NAS100.cash": ["USD"],
            "AUDUSD": ["AUD", "USD"], "NZDUSD": ["NZD", "USD"],
        }
        result = currency_map.get(symbol, ["USD"])
        # Always watch USD
        if "USD" not in result:
            result.append("USD")
        return list(set(result))

    @staticmethod
    def _hardcoded_events() -> list:
        """
        Fallback: returns empty list.
        In production, you could hardcode next week's key events here.
        """
        return []

    def format_news_warning(self, symbol: str) -> str:
        """Returns a formatted string of upcoming events for the alert message."""
        events = self.next_events(symbol, 3)
        if not events:
            return "No high-impact news in the next 2 hours."

        now_utc = datetime.now(tz=timezone.utc)
        lines = []
        for e in events:
            mins = int((e["time"] - now_utc).total_seconds() / 60)
            ist_time = e["time"] + timedelta(hours=5, minutes=30)
            lines.append(
                f"  • {e['title']} ({e['currency']}) — "
                f"{ist_time.strftime('%I:%M %p')} IST ({mins} min away)"
            )
        return "Upcoming news:\n" + "\n".join(lines)
