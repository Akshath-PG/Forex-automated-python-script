"""
=============================================================
  CORE — MT5 DATA HANDLER
  Handles connection, live candle feed, historical download,
  spread checking, and ATR calculation.
=============================================================
"""

import MetaTrader5 as mt5
import pandas as pd
import numpy as np
from datetime import datetime, timezone, timedelta
import logging
import time
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.settings import *

logger = logging.getLogger(__name__)

# ── MT5 timeframe map ─────────────────────────────────────
TF_MAP = {
    "M1":  mt5.TIMEFRAME_M1,
    "M5":  mt5.TIMEFRAME_M5,
    "M15": mt5.TIMEFRAME_M15,
    "M30": mt5.TIMEFRAME_M30,
    "H1":  mt5.TIMEFRAME_H1,
    "H4":  mt5.TIMEFRAME_H4,
    "D1":  mt5.TIMEFRAME_D1,
    "W1":  mt5.TIMEFRAME_W1,
}


class MT5Handler:
    """
    Manages MT5 connection and all data retrieval.
    Keeps a rolling in-memory cache so live tick scanning
    doesn't re-query MT5 every second unnecessarily.
    """

    def __init__(self):
        self.connected = False
        self._cache = {}          # symbol → {tf → DataFrame}
        self._cache_time = {}     # symbol → {tf → last_update_time}
        self.CACHE_TTL = 55       # seconds before refreshing a candle cache

    # ── Connection ────────────────────────────────────────

    def connect(self) -> bool:
        if not mt5.initialize():
            logger.error(f"MT5 initialize() failed: {mt5.last_error()}")
            return False
        authorized = mt5.login(MT5_LOGIN, password=MT5_PASSWORD, server=MT5_SERVER)
        if not authorized:
            logger.error(f"MT5 login failed: {mt5.last_error()}")
            mt5.shutdown()
            return False
        info = mt5.account_info()
        logger.info(f"MT5 connected — Account: {info.login} | Balance: {info.balance} {info.currency}")
        self.connected = True
        return True

    def disconnect(self):
        mt5.shutdown()
        self.connected = False
        logger.info("MT5 disconnected.")

    def ensure_connected(self):
        if not self.connected:
            return self.connect()
        if mt5.account_info() is None:
            logger.warning("MT5 connection lost — reconnecting...")
            self.connected = False
            return self.connect()
        return True

    # ── Candle data ───────────────────────────────────────

    def get_candles(self, symbol: str, tf: str, count: int,
                    use_cache: bool = True) -> pd.DataFrame:
        """
        Returns a DataFrame of OHLCV candles.
        Columns: time, open, high, low, close, tick_volume, spread
        All times in UTC.
        """
        if not self.ensure_connected():
            return pd.DataFrame()

        cache_key = f"{symbol}_{tf}"
        now = time.time()

        if use_cache and cache_key in self._cache:
            age = now - self._cache_time.get(cache_key, 0)
            if age < self.CACHE_TTL:
                df = self._cache[cache_key]
                return df.tail(count).copy()

        mt5_tf = TF_MAP.get(tf)
        if mt5_tf is None:
            logger.error(f"Unknown timeframe: {tf}")
            return pd.DataFrame()

        rates = mt5.copy_rates_from_pos(symbol, mt5_tf, 0, count)
        if rates is None or len(rates) == 0:
            logger.warning(f"No candles returned for {symbol} {tf}: {mt5.last_error()}")
            return pd.DataFrame()

        df = pd.DataFrame(rates)
        df['time'] = pd.to_datetime(df['time'], unit='s', utc=True)
        df.set_index('time', inplace=True)
        df = df[['open', 'high', 'low', 'close', 'tick_volume', 'spread']].copy()
        df.sort_index(inplace=True)

        # Compute ATR immediately
        df = self._add_atr(df, ATR_PERIOD)

        self._cache[cache_key] = df
        self._cache_time[cache_key] = now
        return df.tail(count).copy()

    def get_multi_tf(self, symbol: str) -> dict:
        """
        Returns all timeframes at once for a symbol.
        Returns: { 'H4': df, 'H1': df, 'M15': df, 'M5': df, 'M1': df }
        """
        return {
            "H4":  self.get_candles(symbol, TF_HTF,   CANDLES_HTF),
            "H1":  self.get_candles(symbol, TF_MTF,   CANDLES_MTF),
            "M15": self.get_candles(symbol, TF_ENTRY,  CANDLES_ENTRY),
            "M5":  self.get_candles(symbol, TF_LTF,    CANDLES_LTF),
            "M1":  self.get_candles(symbol, TF_MICRO,  CANDLES_MICRO),
        }

    # ── Historical data for training ─────────────────────

    def download_history(self, symbol: str, tf: str,
                         years: int = 4) -> pd.DataFrame:
        """
        Downloads 'years' of historical data for ML training.
        Pulls in chunks of 10,000 candles to avoid MT5 limits.
        Quality filtering:
          - Removes zero-volume candles (gaps / weekends)
          - Removes candles where OHLC are all equal (broker padding)
          - Removes extreme outliers (price > 5σ from rolling mean)
        """
        if not self.ensure_connected():
            return pd.DataFrame()

        mt5_tf = TF_MAP.get(tf)
        date_to   = datetime.now(tz=timezone.utc)
        date_from = date_to - timedelta(days=365 * years)

        logger.info(f"Downloading {years}y of {symbol} {tf} from {date_from.date()} to {date_to.date()}")

        rates = mt5.copy_rates_range(symbol, mt5_tf, date_from, date_to)
        if rates is None or len(rates) == 0:
            logger.error(f"No historical data for {symbol} {tf}: {mt5.last_error()}")
            return pd.DataFrame()

        df = pd.DataFrame(rates)
        df['time'] = pd.to_datetime(df['time'], unit='s', utc=True)
        df.set_index('time', inplace=True)
        df = df[['open', 'high', 'low', 'close', 'tick_volume', 'spread']].copy()
        df.sort_index(inplace=True)

        raw_count = len(df)

        # ── Quality filters ───────────────────────────────
        # 1. Remove zero-volume candles
        df = df[df['tick_volume'] > 0]

        # 2. Remove candles where all OHLC are equal (broker padding)
        df = df[~((df['open'] == df['high']) &
                  (df['high'] == df['low']) &
                  (df['low'] == df['close']))]

        # 3. Remove weekends and known gap periods (Friday 21:00 UTC → Sunday 21:00 UTC)
        df = df[~((df.index.dayofweek == 5) |   # Saturday
                  ((df.index.dayofweek == 6) & (df.index.hour < 21)))]  # Sunday pre-open

        # 4. Remove extreme price outliers (> 5σ from 200-candle rolling mean)
        roll_mean = df['close'].rolling(200, min_periods=50).mean()
        roll_std  = df['close'].rolling(200, min_periods=50).std()
        df = df[abs(df['close'] - roll_mean) < (5 * roll_std)]

        # 5. Remove abnormally large spreads (> 5× median spread)
        median_spread = df['spread'].median()
        df = df[df['spread'] <= max(median_spread * 5, 10)]

        clean_count = len(df)
        removed = raw_count - clean_count
        logger.info(f"{symbol} {tf}: {raw_count} raw → {clean_count} clean "
                    f"({removed} removed = {100*removed/max(raw_count,1):.1f}%)")

        df = self._add_atr(df, ATR_PERIOD)
        return df

    # ── Current price / symbol info ───────────────────────

    def get_current_price(self, symbol: str) -> dict:
        tick = mt5.symbol_info_tick(symbol)
        if tick is None:
            return {}
        return {"bid": tick.bid, "ask": tick.ask,
                "spread": round((tick.ask - tick.bid) / self.get_pip_size(symbol), 1),
                "time": datetime.fromtimestamp(tick.time, tz=timezone.utc)}

    def get_account_balance(self) -> float:
        info = mt5.account_info()
        return info.balance if info else 0.0

    def get_pip_size(self, symbol: str) -> float:
        """Returns pip size for the symbol (0.0001 for FX, 0.01 for JPY, 0.1 for gold etc.)"""
        info = mt5.symbol_info(symbol)
        if info is None:
            return 0.0001
        digits = info.digits
        if digits == 3 or digits == 2:
            return 0.01
        if digits == 1:
            return 0.1
        return 0.0001 if digits >= 4 else 0.01

    def get_point_value(self, symbol: str) -> float:
        info = mt5.symbol_info(symbol)
        return info.trade_contract_size * info.point if info else 10.0

    def get_open_trades_count(self) -> int:
        positions = mt5.positions_get()
        return len(positions) if positions else 0

    def get_spread_pips(self, symbol: str) -> float:
        price = self.get_current_price(symbol)
        return price.get('spread', 999)

    # ── Order placement ───────────────────────────────────

    def place_order(self, symbol: str, direction: str,
                    entry: float, sl: float, tp: float,
                    lot: float, comment: str = "ForexBot") -> dict:
        """
        Places a market order in MT5.
        direction: 'BUY' or 'SELL'
        Returns result dict with ticket number or error.
        """
        if not self.ensure_connected():
            return {"success": False, "error": "Not connected to MT5"}

        order_type = mt5.ORDER_TYPE_BUY if direction == "BUY" else mt5.ORDER_TYPE_SELL
        price_info = self.get_current_price(symbol)
        price = price_info.get('ask' if direction == "BUY" else 'bid', entry)

        request = {
            "action":    mt5.TRADE_ACTION_DEAL,
            "symbol":    symbol,
            "volume":    lot,
            "type":      order_type,
            "price":     price,
            "sl":        sl,
            "tp":        tp,
            "deviation": 10,
            "magic":     20240101,
            "comment":   comment,
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }

        result = mt5.order_send(request)
        if result.retcode == mt5.TRADE_RETCODE_DONE:
            logger.info(f"Order placed — {direction} {lot} {symbol} @ {price} | Ticket: {result.order}")
            return {"success": True, "ticket": result.order, "price": price,
                    "sl": sl, "tp": tp, "lot": lot}
        else:
            logger.error(f"Order failed — retcode: {result.retcode} | comment: {result.comment}")
            return {"success": False, "error": f"{result.retcode}: {result.comment}"}

    def calculate_lot_size(self, symbol: str, sl_pips: float) -> float:
        """
        Auto-calculate lot size based on RISK_PERCENT_PER_TRADE.
        Uses: lot = (balance × risk%) / (sl_pips × pip_value_per_lot)
        """
        balance = self.get_account_balance()
        if balance == 0 or sl_pips == 0:
            return DEFAULT_LOT_SIZE

        info = mt5.symbol_info(symbol)
        if info is None:
            return DEFAULT_LOT_SIZE

        risk_amount   = balance * (RISK_PERCENT_PER_TRADE / 100)
        pip_size      = self.get_pip_size(symbol)
        tick_value    = info.trade_tick_value
        tick_size     = info.trade_tick_size
        pip_value_lot = (pip_size / tick_size) * tick_value  # value per pip per 1 lot

        if pip_value_lot == 0:
            return DEFAULT_LOT_SIZE

        raw_lot = risk_amount / (sl_pips * pip_value_lot)
        lot = round(raw_lot / info.volume_step) * info.volume_step
        lot = max(info.volume_min, min(lot, info.volume_max))
        return round(lot, 2)

    # ── Internal helpers ──────────────────────────────────

    @staticmethod
    def _add_atr(df: pd.DataFrame, period: int) -> pd.DataFrame:
        """Adds ATR column using Wilder's method."""
        high, low, close = df['high'], df['low'], df['close']
        prev_close = close.shift(1)
        tr = pd.concat([
            high - low,
            (high - prev_close).abs(),
            (low - prev_close).abs()
        ], axis=1).max(axis=1)
        df['atr'] = tr.ewm(alpha=1/period, adjust=False).mean()
        return df
