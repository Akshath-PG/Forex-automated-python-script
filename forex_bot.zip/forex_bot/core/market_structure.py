"""
=============================================================
  CORE — MARKET STRUCTURE ANALYSER
  Detects: HTF trend, Break of Structure (BOS), Change of
  Character (CHoCH), Order Blocks, Fair Value Gaps (FVG),
  Liquidity levels, and Equal Highs/Lows.
=============================================================
"""

import pandas as pd
import numpy as np
import logging
from dataclasses import dataclass, field
from typing import Optional
import os, sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.settings import *

logger = logging.getLogger(__name__)


# ── Data classes ──────────────────────────────────────────

@dataclass
class OrderBlock:
    direction: str          # 'bullish' or 'bearish'
    high: float
    low: float
    mid: float
    body_high: float
    body_low: float
    formed_at: object       # timestamp
    candles_ago: int
    impulse_size_atr: float # how strong the move away from OB was (in ATR)
    mitigated: bool = False
    strength: float = 0.0   # 0-100

@dataclass
class FairValueGap:
    direction: str          # 'bullish' or 'bearish'
    top: float
    bottom: float
    mid: float
    formed_at: object
    candles_ago: int
    size_pips: float
    filled: bool = False

@dataclass
class LiquidityLevel:
    level_type: str         # 'swing_high', 'swing_low', 'equal_highs', 'equal_lows'
    price: float
    formed_at: object
    strength: int           # how many times it was tested

@dataclass
class MarketStructure:
    symbol: str
    # ── Trend ─────────────────────────────────────────────
    htf_trend: str          # 'bullish', 'bearish', 'ranging'
    mtf_trend: str
    htf_swing_high: float = 0.0
    htf_swing_low: float  = 0.0
    # ── Structure events ──────────────────────────────────
    last_bos: Optional[str] = None   # 'bullish' or 'bearish'
    last_choch: Optional[str] = None
    # ── Key levels ────────────────────────────────────────
    order_blocks: list = field(default_factory=list)
    fvgs: list = field(default_factory=list)
    liquidity_levels: list = field(default_factory=list)
    # ── Session context ───────────────────────────────────
    current_session: str = "off"
    prev_session_high: float = 0.0
    prev_session_low: float  = 0.0
    # ── Summary ───────────────────────────────────────────
    bias: str = "neutral"   # final directional bias after all analysis


class MarketStructureAnalyser:
    """
    Multi-timeframe market structure engine.
    Designed to mimic what an ICT/SMC trader does manually:
      1. Determine HTF trend (H4)
      2. Map out order blocks and liquidity on H1
      3. Find FVGs and precise entry levels on M15/M5
    """

    def __init__(self, mt5_handler):
        self.mt5 = mt5_handler

    def analyse(self, symbol: str, candles: dict) -> MarketStructure:
        """
        Full multi-timeframe analysis.
        candles = { 'H4': df, 'H1': df, 'M15': df, 'M5': df, 'M1': df }
        """
        h4  = candles.get("H4",  pd.DataFrame())
        h1  = candles.get("H1",  pd.DataFrame())
        m15 = candles.get("M15", pd.DataFrame())
        m5  = candles.get("M5",  pd.DataFrame())

        htf_trend, h_high, h_low = self._detect_trend(h4)
        mtf_trend, _, _          = self._detect_trend(h1)

        ms = MarketStructure(
            symbol=symbol,
            htf_trend=htf_trend,
            mtf_trend=mtf_trend,
            htf_swing_high=h_high,
            htf_swing_low=h_low,
        )

        # BOS and CHoCH on H1
        ms.last_bos, ms.last_choch = self._detect_bos_choch(h1)

        # Order Blocks — from H1 (primary) and M15 (refined)
        ms.order_blocks = (
            self._find_order_blocks(h1,  "H1")  +
            self._find_order_blocks(m15, "M15")
        )
        ms.order_blocks = [ob for ob in ms.order_blocks if not ob.mitigated]
        ms.order_blocks.sort(key=lambda x: x.strength, reverse=True)

        # FVGs — from M15 and M5
        ms.fvgs = (
            self._find_fvgs(m15, "M15") +
            self._find_fvgs(m5,  "M5")
        )
        ms.fvgs = [f for f in ms.fvgs if not f.filled]

        # Liquidity levels
        ms.liquidity_levels = self._find_liquidity(h4, h1)

        # Session context
        ms.current_session = get_current_session()
        ms.prev_session_high, ms.prev_session_low = self._get_prev_session_range(h1)

        # Final bias
        ms.bias = self._compute_bias(ms)

        return ms

    # ── Trend detection ───────────────────────────────────

    def _detect_trend(self, df: pd.DataFrame, lookback: int = 100):
        """
        ICT-style trend: higher highs + higher lows = bullish,
        lower highs + lower lows = bearish, otherwise ranging.
        Uses last 3 swing highs and 3 swing lows.
        """
        if len(df) < 50:
            return "ranging", 0.0, 0.0

        swings_h = self._find_swing_highs(df, lookback=lookback, n=3)
        swings_l = self._find_swing_lows(df, lookback=lookback, n=3)

        if len(swings_h) < 2 or len(swings_l) < 2:
            return "ranging", 0.0, 0.0

        # Check for HH and HL (bullish)
        hh = swings_h[-1] > swings_h[-2]   # higher high
        hl = swings_l[-1] > swings_l[-2]   # higher low
        lh = swings_h[-1] < swings_h[-2]   # lower high
        ll = swings_l[-1] < swings_l[-2]   # lower low

        if hh and hl:
            trend = "bullish"
        elif lh and ll:
            trend = "bearish"
        elif hh and ll:
            trend = "ranging"   # expanding
        else:
            trend = "ranging"

        return trend, swings_h[-1], swings_l[-1]

    def _find_swing_highs(self, df, lookback=100, n=3, pivot_len=5):
        """Returns last n swing highs using left/right pivot detection."""
        highs = []
        data = df['high'].values[-lookback:]
        for i in range(pivot_len, len(data) - pivot_len):
            if data[i] == max(data[i - pivot_len: i + pivot_len + 1]):
                highs.append(data[i])
        return highs[-n:] if highs else []

    def _find_swing_lows(self, df, lookback=100, n=3, pivot_len=5):
        lows = []
        data = df['low'].values[-lookback:]
        for i in range(pivot_len, len(data) - pivot_len):
            if data[i] == min(data[i - pivot_len: i + pivot_len + 1]):
                lows.append(data[i])
        return lows[-n:] if lows else []

    # ── BOS / CHoCH ───────────────────────────────────────

    def _detect_bos_choch(self, df: pd.DataFrame):
        """
        Break of Structure (BOS): price breaks a swing high/low
          in the direction of the EXISTING trend — continuation.
        Change of Character (CHoCH): price breaks a swing high/low
          AGAINST the existing trend — potential reversal warning.

        Returns: (last_bos: str|None, last_choch: str|None)
        """
        if len(df) < 30:
            return None, None

        closes = df['close'].values
        highs  = df['high'].values
        lows   = df['low'].values
        last_bos = None
        last_choch = None

        pivot = 5
        for i in range(pivot + 1, len(df) - 1):
            # Check if previous swing high was broken
            window_high = highs[i - 2 * pivot: i - pivot]
            window_low  = lows[i - 2 * pivot: i - pivot]
            if len(window_high) == 0:
                continue

            prev_swing_high = max(window_high)
            prev_swing_low  = min(window_low)

            # Bullish BOS: close above prior swing high
            if closes[i] > prev_swing_high:
                last_bos = "bullish"

            # Bearish BOS: close below prior swing low
            if closes[i] < prev_swing_low:
                last_bos = "bearish"

        # CHoCH: last BOS is opposite to the dominant trend direction
        # Simplified: if last BOS just changed, it's a CHoCH candidate
        # (full CHoCH requires cross-referencing with HTF trend — done in strategy)
        last_choch = last_bos   # strategies further filter this
        return last_bos, last_choch

    # ── Order Blocks ──────────────────────────────────────

    def _find_order_blocks(self, df: pd.DataFrame, tf: str) -> list:
        """
        ICT Order Block rules:
        - Bullish OB: last DOWN candle before a strong bullish impulse
          (impulse must be ≥ OB_MIN_IMPULSE_ATR_MULT × ATR)
        - Bearish OB: last UP candle before a strong bearish impulse
        - OB is the full candle range (high to low)
        - OB is valid until price closes past its 50% midpoint
        - Strength scoring: impulse size + recency + how many times tested
        """
        if len(df) < 10:
            return []

        obs = []
        opens  = df['open'].values
        closes = df['close'].values
        highs  = df['high'].values
        lows   = df['low'].values
        atrs   = df['atr'].values
        times  = df.index

        for i in range(1, len(df) - 1):
            atr = atrs[i] if not np.isnan(atrs[i]) else 0.001

            # ── Bearish OB ─────────────────────────────────
            # Candle i is bullish (up candle) AND
            # candle i+1 is a strong bearish impulse
            is_up_candle   = closes[i] > opens[i]
            next_is_impulse = (closes[i + 1] < opens[i + 1] and
                               abs(closes[i + 1] - opens[i + 1]) >= OB_MIN_IMPULSE_ATR_MULT * atr)

            if is_up_candle and next_is_impulse:
                # Check if price has since mitigated this OB
                ob_mid = (highs[i] + lows[i]) / 2
                future_closes = closes[i + 1:]
                mitigated = any(c > ob_mid for c in future_closes)  # price retraced above mid

                # Count tests (how many times price touched the OB zone)
                tests = sum(1 for j in range(i + 1, len(df))
                            if lows[j] <= highs[i] and highs[j] >= lows[i])

                impulse_atr = abs(closes[i + 1] - opens[i + 1]) / atr
                strength = min(100, impulse_atr * 20 + tests * 10)

                obs.append(OrderBlock(
                    direction="bearish",
                    high=highs[i], low=lows[i], mid=ob_mid,
                    body_high=max(opens[i], closes[i]),
                    body_low=min(opens[i], closes[i]),
                    formed_at=times[i],
                    candles_ago=len(df) - 1 - i,
                    impulse_size_atr=round(impulse_atr, 2),
                    mitigated=mitigated,
                    strength=round(strength, 1),
                ))

            # ── Bullish OB ─────────────────────────────────
            is_down_candle  = closes[i] < opens[i]
            next_is_bull    = (closes[i + 1] > opens[i + 1] and
                               abs(closes[i + 1] - opens[i + 1]) >= OB_MIN_IMPULSE_ATR_MULT * atr)

            if is_down_candle and next_is_bull:
                ob_mid = (highs[i] + lows[i]) / 2
                future_closes = closes[i + 1:]
                mitigated = any(c < ob_mid for c in future_closes)

                tests = sum(1 for j in range(i + 1, len(df))
                            if lows[j] <= highs[i] and highs[j] >= lows[i])

                impulse_atr = abs(closes[i + 1] - opens[i + 1]) / atr
                strength = min(100, impulse_atr * 20 + tests * 10)

                obs.append(OrderBlock(
                    direction="bullish",
                    high=highs[i], low=lows[i], mid=ob_mid,
                    body_high=max(opens[i], closes[i]),
                    body_low=min(opens[i], closes[i]),
                    formed_at=times[i],
                    candles_ago=len(df) - 1 - i,
                    impulse_size_atr=round(impulse_atr, 2),
                    mitigated=mitigated,
                    strength=round(strength, 1),
                ))

        # Filter: only recent OBs
        obs = [ob for ob in obs if ob.candles_ago <= OB_MAX_CANDLES_AGO]
        return obs

    # ── Fair Value Gaps ───────────────────────────────────

    def _find_fvgs(self, df: pd.DataFrame, tf: str) -> list:
        """
        FVG = 3-candle pattern where candle 1 high < candle 3 low (bullish FVG)
        or candle 1 low > candle 3 high (bearish FVG).
        The gap between candle 1 and candle 3 is the FVG zone.
        Price is magnetically drawn back to fill FVGs.
        """
        if len(df) < 4:
            return []

        fvgs = []
        pip_size = self.mt5.get_pip_size(df.index.name or "EURUSD")
        highs  = df['high'].values
        lows   = df['low'].values
        times  = df.index

        for i in range(1, len(df) - 1):
            # Bullish FVG: gap between candle[i-1] high and candle[i+1] low
            if lows[i + 1] > highs[i - 1]:
                size_pips = (lows[i + 1] - highs[i - 1]) / max(pip_size, 0.00001)
                if size_pips >= FVG_MIN_SIZE_PIPS:
                    candles_ago = len(df) - 1 - i
                    # Check if FVG has been filled (price came back to it)
                    future_lows = lows[i + 1:]
                    filled = any(l <= highs[i - 1] for l in future_lows)
                    if candles_ago <= FVG_MAX_AGE_CANDLES:
                        fvgs.append(FairValueGap(
                            direction="bullish",
                            top=lows[i + 1], bottom=highs[i - 1],
                            mid=(lows[i + 1] + highs[i - 1]) / 2,
                            formed_at=times[i], candles_ago=candles_ago,
                            size_pips=round(size_pips, 1), filled=filled,
                        ))

            # Bearish FVG: gap between candle[i-1] low and candle[i+1] high
            if highs[i + 1] < lows[i - 1]:
                size_pips = (lows[i - 1] - highs[i + 1]) / max(pip_size, 0.00001)
                if size_pips >= FVG_MIN_SIZE_PIPS:
                    candles_ago = len(df) - 1 - i
                    future_highs = highs[i + 1:]
                    filled = any(h >= lows[i - 1] for h in future_highs)
                    if candles_ago <= FVG_MAX_AGE_CANDLES:
                        fvgs.append(FairValueGap(
                            direction="bearish",
                            top=lows[i - 1], bottom=highs[i + 1],
                            mid=(lows[i - 1] + highs[i + 1]) / 2,
                            formed_at=times[i], candles_ago=candles_ago,
                            size_pips=round(size_pips, 1), filled=filled,
                        ))

        return fvgs

    # ── Liquidity ─────────────────────────────────────────

    def _find_liquidity(self, h4: pd.DataFrame, h1: pd.DataFrame) -> list:
        """
        Finds equal highs/lows and obvious swing liquidity pools
        that smart money is likely to target before reversing.
        """
        levels = []
        for df, threshold in [(h4, 5), (h1, 10)]:
            if len(df) < 20:
                continue
            highs = df['high'].values[-60:]
            lows  = df['low'].values[-60:]
            times = df.index[-60:]
            atr   = df['atr'].values[-1] if 'atr' in df.columns else 0.001

            for i in range(len(highs)):
                # Count how many highs cluster within 0.5 ATR
                count = sum(1 for j in range(len(highs))
                            if j != i and abs(highs[j] - highs[i]) < 0.5 * atr)
                if count >= 1:  # at least 2 touches = equal highs
                    levels.append(LiquidityLevel(
                        level_type="equal_highs" if count >= 2 else "swing_high",
                        price=highs[i], formed_at=times[i], strength=count + 1,
                    ))

                count = sum(1 for j in range(len(lows))
                            if j != i and abs(lows[j] - lows[i]) < 0.5 * atr)
                if count >= 1:
                    levels.append(LiquidityLevel(
                        level_type="equal_lows" if count >= 2 else "swing_low",
                        price=lows[i], formed_at=times[i], strength=count + 1,
                    ))

        return levels

    # ── Session range ─────────────────────────────────────

    def _get_prev_session_range(self, df: pd.DataFrame):
        """Returns the high and low of the previous session (Asian or London)."""
        if len(df) < 12:
            return 0.0, 0.0
        last_24 = df.tail(24)
        return last_24['high'].max(), last_24['low'].min()

    # ── Bias computation ──────────────────────────────────

    def _compute_bias(self, ms: MarketStructure) -> str:
        """
        Combines HTF trend + MTF BOS + OB alignment to produce
        a final directional bias: 'bullish', 'bearish', 'neutral'.
        """
        score = 0
        if ms.htf_trend == "bullish":
            score += 2
        elif ms.htf_trend == "bearish":
            score -= 2

        if ms.mtf_trend == "bullish":
            score += 1
        elif ms.mtf_trend == "bearish":
            score -= 1

        if ms.last_bos == "bullish":
            score += 1
        elif ms.last_bos == "bearish":
            score -= 1

        if score >= 2:
            return "bullish"
        elif score <= -2:
            return "bearish"
        return "neutral"


# ── Session utilities ─────────────────────────────────────

def get_current_session() -> str:
    """Returns current session name based on UTC time."""
    from datetime import datetime, timezone
    now_utc = datetime.now(tz=timezone.utc)
    hour = now_utc.hour + now_utc.minute / 60

    if 7.0 <= hour < 9.0:
        return "london_open"
    elif 9.0 <= hour < 12.0:
        return "london_main"
    elif 12.0 <= hour < 15.0:
        return "ny_open"
    elif 15.0 <= hour < 17.0:
        return "ny_main"
    elif 0.0 <= hour < 8.0:
        return "asian"
    return "off"


def is_in_silver_bullet_window() -> bool:
    from datetime import datetime, timezone
    now_utc = datetime.now(tz=timezone.utc)
    hour = now_utc.hour + now_utc.minute / 60
    for w in SILVER_BULLET_WINDOWS:
        sh, sm = map(int, w["start"].split(":"))
        eh, em = map(int, w["end"].split(":"))
        start = sh + sm / 60
        end   = eh + em / 60
        if start <= hour < end:
            return True
    return False
