"""
=============================================================
  FOREX BOT — CENTRAL CONFIGURATION
  All user-tunable settings live here. Edit this file only.
=============================================================
"""

# ── MT5 Connection ────────────────────────────────────────
MT5_LOGIN      = 12345678          # your MT5 account number
MT5_PASSWORD   = "YourPassword"
MT5_SERVER     = "YourBroker-Server"  # e.g. "ICMarkets-Live"

# ── Broker Timezone ──────────────────────────────────────
# Your broker's MT5 server is at GMT+5:30 (IST)
BROKER_TZ_OFFSET_HOURS = 5.5       # IST offset from UTC

# ── Telegram ─────────────────────────────────────────────
TELEGRAM_BOT_TOKEN = "YOUR_BOT_TOKEN"
TELEGRAM_CHAT_ID   = "YOUR_CHAT_ID"   # your personal chat ID

# ── WhatsApp (Twilio) ─────────────────────────────────────
TWILIO_ACCOUNT_SID  = "YOUR_TWILIO_SID"
TWILIO_AUTH_TOKEN   = "YOUR_TWILIO_TOKEN"
TWILIO_FROM_NUMBER  = "whatsapp:+14155238886"   # Twilio sandbox or approved number
YOUR_WHATSAPP_NUMBER = "whatsapp:+91XXXXXXXXXX" # your WhatsApp number with country code

# ── Pairs to monitor ─────────────────────────────────────
SYMBOLS = [
    "EURUSD", "GBPUSD", "USDJPY", "USDCHF",  # Forex majors
    "XAUUSD",                                  # Gold
    "XAGUSD",                                  # Silver
    "US30.cash", "NAS100.cash",                # Indices — adjust to your broker's naming
]

# ── Risk Management ───────────────────────────────────────
RISK_PERCENT_PER_TRADE = 1.0        # % of account balance per trade
MIN_RR_RATIO           = 2.0        # minimum Risk:Reward to alert (1:2)
MAX_SPREAD_PIPS        = 3.0        # skip if spread exceeds this
MAX_CONCURRENT_TRADES  = 3          # never more than 3 open at once
DEFAULT_LOT_SIZE       = 0.01       # fallback lot if auto-calc fails

# ── Confluence scoring ────────────────────────────────────
MIN_CONFLUENCE_SCORE   = 60         # 0-100 — below this, no alert
ML_SCORE_WEIGHT        = 0.4        # weight of ML model in final score
RULE_SCORE_WEIGHT      = 0.6        # weight of rule-based score

# ── Timeframes used (as MT5 constants) ───────────────────
# HTF = higher timeframe for bias
# MTF = medium timeframe for structure
# LTF = lower timeframe for entry precision
TF_HTF  = "H4"     # trend / bias
TF_MTF  = "H1"     # structure / order blocks
TF_ENTRY = "M15"   # refined entry
TF_LTF   = "M5"    # LTF confirmation (candle patterns, FVG precision)
TF_MICRO = "M1"    # Silver Bullet FVG detection

# ── Lookback settings ────────────────────────────────────
CANDLES_HTF    = 500   # H4 candles to load
CANDLES_MTF    = 500   # H1 candles
CANDLES_ENTRY  = 500   # M15 candles
CANDLES_LTF    = 300   # M5 candles
CANDLES_MICRO  = 200   # M1 candles (Silver Bullet window only)

# ── Session times (all in UTC) ────────────────────────────
# Add 5.5 hours to get IST equivalent
SESSIONS = {
    "asian":         {"start": "00:00", "end": "08:00"},  # UTC
    "london_open":   {"start": "07:00", "end": "09:00"},  # London kill zone
    "london_main":   {"start": "08:00", "end": "12:00"},
    "ny_open":       {"start": "12:00", "end": "15:00"},  # NY kill zone
    "ny_main":       {"start": "13:00", "end": "17:00"},
    "overlap":       {"start": "12:00", "end": "16:00"},  # London-NY overlap — highest volume
}

# Silver Bullet specific windows (UTC)
SILVER_BULLET_WINDOWS = [
    {"start": "03:00", "end": "04:00"},   # London 10-11am
    {"start": "08:00", "end": "09:00"},   # NY 10-11am
    {"start": "13:00", "end": "14:00"},   # NY 2-3pm (afternoon)
]

# ── Strategy toggles ──────────────────────────────────────
STRATEGIES_ENABLED = {
    "silver_bullet":   True,
    "session_trading": True,
    "smc_ob":          True,
    "turtle_soup":     True,
    "kiss_of_death":   True,
    "news_entry":      True,
}

# ── News filter ───────────────────────────────────────────
NEWS_BLOCK_MINUTES_BEFORE = 20   # block trades 20 min before high-impact news
NEWS_BLOCK_MINUTES_AFTER  = 15   # block trades 15 min after
NEWS_CURRENCIES_TO_WATCH  = ["USD", "EUR", "GBP", "JPY", "XAU"]

# ── Turtle soup settings ──────────────────────────────────
TURTLE_LOOKBACK_BARS     = 20    # swing high/low lookback
TURTLE_BUFFER_PIPS       = 2     # how many pips beyond swing = valid sweep
TURTLE_MAX_SWEEP_CANDLES = 3     # sweep must reverse within this many candles

# ── Order block settings ──────────────────────────────────
OB_MAX_CANDLES_AGO       = 50    # OB must be formed within this many candles
OB_MIN_IMPULSE_ATR_MULT  = 1.5   # impulse candle must be 1.5× ATR minimum
OB_MITIGATED_THRESHOLD   = 0.5   # OB is mitigated if price closes past 50% of it

# ── FVG settings ─────────────────────────────────────────
FVG_MIN_SIZE_PIPS        = 2.0   # minimum FVG size to be valid
FVG_MAX_AGE_CANDLES      = 30    # ignore FVGs older than this

# ── ATR period ────────────────────────────────────────────
ATR_PERIOD = 14

# ── Logging ───────────────────────────────────────────────
LOG_FILE = "logs/bot.log"
LOG_LEVEL = "INFO"    # DEBUG for development, INFO for live

# ── Data paths ───────────────────────────────────────────
DATA_DIR       = "data/"
MODEL_PATH     = "ml/trained_model.pkl"
SCALER_PATH    = "ml/scaler.pkl"
FEATURES_PATH  = "ml/feature_names.pkl"
